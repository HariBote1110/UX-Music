package playlist

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"ux-music-sidecar/internal/config"
)

const (
	PlaylistsDirName      = "Playlists"
	PlaylistOrderFileName = "playlist-order"
	FavoritesPlaylistName = "お気に入り"
)

// SettingsProvider abstracts loading a persisted settings map, decoupling
// this package from internal/store's concrete singleton implementation.
type SettingsProvider interface {
	LoadMap(name string) (map[string]interface{}, error)
}

var settingsProvider SettingsProvider

// SetSettingsProvider injects the SettingsProvider implementation used to
// read the persisted playlist order. Callers (e.g. server/) should call
// this during initialisation, passing internal/store's Instance or an
// equivalent implementation.
func SetSettingsProvider(provider SettingsProvider) {
	settingsProvider = provider
}

func loadSettingsMap(name string) map[string]interface{} {
	if settingsProvider == nil {
		return map[string]interface{}{}
	}
	m, err := settingsProvider.LoadMap(name)
	if err != nil {
		return map[string]interface{}{}
	}
	return m
}

func GetPlaylistsDir() string {
	dir := filepath.Join(config.GetUserDataPath(), PlaylistsDirName)
	if _, err := os.Stat(dir); os.IsNotExist(err) {
		os.MkdirAll(dir, 0755)
	}
	return dir
}

// PlaylistEntry represents a single song entry in an M3U8 file
type PlaylistEntry struct {
	Path     string
	Duration int
	Title    string
}

func parseM3U8(content string) []PlaylistEntry {
	lines := strings.Split(content, "\n")
	var entries []PlaylistEntry

	for i := 0; i < len(lines); i++ {
		line := strings.TrimSpace(lines[i])
		if strings.HasPrefix(line, "#EXTINF:") {
			parts := strings.SplitN(line[8:], ",", 2)
			duration := 0
			title := ""
			if len(parts) >= 2 {
				fmt.Sscanf(parts[0], "%d", &duration)
				title = parts[1]
			}

			if i+1 < len(lines) {
				pathLine := strings.TrimSpace(lines[i+1])
				if pathLine != "" && !strings.HasPrefix(pathLine, "#") {
					entries = append(entries, PlaylistEntry{
						Path:     pathLine,
						Duration: duration,
						Title:    title,
					})
					i++
				}
			}
		}
	}
	return entries
}

func writeM3U8(path string, entries []PlaylistEntry) error {
	var sb strings.Builder
	sb.WriteString("#EXTM3U\n")

	for _, entry := range entries {
		sb.WriteString(fmt.Sprintf("#EXTINF:%d,%s\n", entry.Duration, entry.Title))
		sb.WriteString(entry.Path + "\n")
	}

	return os.WriteFile(path, []byte(sb.String()), 0644)
}

func playlistFilePath(name string) (string, error) {
	cleanName := strings.TrimSpace(name)
	if cleanName == "" {
		return "", fmt.Errorf("empty name")
	}
	if cleanName == "." || cleanName == ".." ||
		strings.ContainsAny(cleanName, `/\`) ||
		filepath.Base(cleanName) != cleanName {
		return "", fmt.Errorf("invalid playlist name")
	}
	return filepath.Join(GetPlaylistsDir(), cleanName+".m3u8"), nil
}

func GetAllPlaylists() ([]string, error) {
	dir := GetPlaylistsDir()
	files, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}

	var names []string
	for _, f := range files {
		if !f.IsDir() && strings.HasSuffix(f.Name(), ".m3u8") {
			names = append(names, strings.TrimSuffix(f.Name(), ".m3u8"))
		}
	}

	orderData := loadSettingsMap(PlaylistOrderFileName)
	var savedOrder []string
	if orderList, ok := orderData["order"].([]interface{}); ok {
		for _, item := range orderList {
			if s, ok := item.(string); ok {
				savedOrder = append(savedOrder, s)
			}
		}
	}

	orderMap := make(map[string]int)
	for i, name := range savedOrder {
		orderMap[name] = i
	}

	sort.Slice(names, func(i, j int) bool {
		idxI, okI := orderMap[names[i]]
		idxJ, okJ := orderMap[names[j]]

		if okI && okJ {
			return idxI < idxJ
		}
		if okI {
			return true
		}
		if okJ {
			return false
		}
		return names[i] < names[j]
	})

	return names, nil
}

func CreatePlaylist(name string) error {
	path, err := playlistFilePath(name)
	if err != nil {
		return err
	}
	if _, err := os.Stat(path); err == nil {
		return fmt.Errorf("playlist already exists")
	}

	return os.WriteFile(path, []byte("#EXTM3U\n"), 0644)
}

func DeletePlaylist(name string) error {
	path, err := playlistFilePath(name)
	if err != nil {
		return err
	}
	return os.Remove(path)
}

func GetPlaylistSongs(name string) ([]string, error) {
	path, err := playlistFilePath(name)
	if err != nil {
		return nil, err
	}
	content, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	entries := parseM3U8(string(content))
	paths := make([]string, len(entries))
	for i, e := range entries {
		paths[i] = e.Path
	}
	return paths, nil
}

type SongToAdd struct {
	Path     string  `json:"path"`
	Duration float64 `json:"duration"`
	Artist   string  `json:"artist"`
	Title    string  `json:"title"`
}

func AddSongsToPlaylist(name string, songs []SongToAdd) (int, error) {
	path, err := playlistFilePath(name)
	if err != nil {
		return 0, err
	}
	content, err := os.ReadFile(path)
	if err != nil {
		return 0, err
	}

	currentEntries := parseM3U8(string(content))
	existingPaths := make(map[string]bool)
	for _, e := range currentEntries {
		existingPaths[e.Path] = true
	}

	addedCount := 0
	for _, s := range songs {
		if !existingPaths[s.Path] {
			currentEntries = append(currentEntries, PlaylistEntry{
				Path:     s.Path,
				Duration: int(s.Duration),
				Title:    fmt.Sprintf("%s - %s", s.Artist, s.Title),
			})
			addedCount++
		}
	}

	if addedCount > 0 {
		err = writeM3U8(path, currentEntries)
	}

	return addedCount, err
}

func RemoveSongsFromPlaylist(name string, pathsToRemove []string) error {
	path, err := playlistFilePath(name)
	if err != nil {
		return err
	}
	content, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	currentEntries := parseM3U8(string(content))
	removeMap := make(map[string]bool)
	for _, p := range pathsToRemove {
		removeMap[p] = true
	}

	var newEntries []PlaylistEntry
	for _, e := range currentEntries {
		if !removeMap[e.Path] {
			newEntries = append(newEntries, e)
		}
	}

	return writeM3U8(path, newEntries)
}

func UpdatePlaylistOrder(name string, newPaths []string) error {
	path, err := playlistFilePath(name)
	if err != nil {
		return err
	}
	content, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	currentEntries := parseM3U8(string(content))
	entryMap := make(map[string]PlaylistEntry)
	for _, e := range currentEntries {
		entryMap[e.Path] = e
	}

	var newEntries []PlaylistEntry
	for _, p := range newPaths {
		if e, ok := entryMap[p]; ok {
			newEntries = append(newEntries, e)
		}
	}

	return writeM3U8(path, newEntries)
}

func RenamePlaylist(oldName, newName string) error {
	oldPath, err := playlistFilePath(oldName)
	if err != nil {
		return err
	}
	newPath, err := playlistFilePath(newName)
	if err != nil {
		return err
	}

	if _, err := os.Stat(newPath); err == nil {
		return fmt.Errorf("destination playlist already exists")
	}

	return os.Rename(oldPath, newPath)
}
