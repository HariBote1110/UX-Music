/**
 * DOM refs populated by `initElements`; keys are assigned dynamically.
 * Values are mixed `HTMLElement`, `NodeListOf<Element>`, etc.; narrow at call sites.
 */
/* eslint-disable @typescript-eslint/no-explicit-any -- legacy DOM bag; narrow where needed */
export const elements: Record<string, any> = {};
/* eslint-enable @typescript-eslint/no-explicit-any */

export function initElements() {
    // Main Containers
    elements.mainContent = document.getElementById('main-content');
    elements.musicList = document.getElementById('main-content');

    elements.nowPlayingArtworkContainer = document.getElementById('now-playing-artwork-container');

    // ▼▼▼ 修正: コンテナ要素自体を取得するように戻しました ▼▼▼
    elements.nowPlayingTitle = document.getElementById('now-playing-title');
    elements.nowPlayingArtist = document.getElementById('now-playing-artist');
    // ▲▲▲ 修正完了 ▲▲▲

    // Playback Controls
    elements.playPauseBtn = document.getElementById('play-pause-btn');
    elements.prevBtn = document.getElementById('prev-btn');
    elements.nextBtn = document.getElementById('next-btn');
    elements.shuffleBtn = document.getElementById('shuffle-btn');
    elements.loopBtn = document.getElementById('loop-btn');
    elements.progressBar = document.getElementById('progress-bar');
    elements.currentTimeEl = document.getElementById('current-time');
    elements.totalDurationEl = document.getElementById('total-duration');
    elements.volumeSlider = document.getElementById('volume-slider');
    elements.volumeIcon = document.getElementById('volume-icon-btn');
    elements.volumeRange = document.getElementById('volume-slider');

    // Devices & Navigation
    elements.deviceSelectButton = document.getElementById('device-select-button');
    elements.devicePopup = document.getElementById('device-popup');
    elements.navLinks = document.querySelectorAll('.nav-link');

    // Modal
    elements.modalOverlay = document.getElementById('modal-overlay');
    elements.modalTitle = document.querySelector('#modal h3');
    elements.modalInput = document.getElementById('modal-input');
    elements.modalOkBtn = document.getElementById('modal-ok-btn');
    elements.modalCancelBtn = document.getElementById('modal-cancel-btn');
    elements.lyricsTranslationModalOverlay = document.getElementById('lyrics-translation-modal-overlay');
    elements.lyricsTranslationPaste = document.getElementById('lyrics-translation-paste');
    elements.lyricsTranslationPasteHint = document.getElementById('lyrics-translation-paste-hint');
    elements.lyricsTranslationSaveBtn = document.getElementById('lyrics-translation-save-btn');
    elements.lyricsTranslationCancelBtn = document.getElementById('lyrics-translation-cancel-btn');
    elements.loadingOverlay = document.getElementById('loading-overlay');

    // Settings
    elements.openSettingsBtn = document.getElementById('open-settings-btn');
    elements.settingsModalOverlay = document.getElementById('settings-modal-overlay');
    elements.settingsOkBtn = document.getElementById('settings-ok-btn');
    elements.notificationToast = document.getElementById('notification-toast');
    elements.notificationText = document.getElementById('notification-text');
    // Sidebar
    elements.lyricsView = document.getElementById('lyrics-view');
    elements.sidebarTabs = document.querySelectorAll('.sidebar-tab-btn');
    elements.sidebarTabContents = document.querySelectorAll('.sidebar-tab-content');
    elements.queueList = document.getElementById('queue-list');
    elements.hubLinkContainer = document.getElementById('hub-link-container');
    elements.dropZone = document.body;

    elements.normalizeViewBtn = document.getElementById('normalize-view-btn');

    // Equalizer elements
    elements.equalizerContainer = document.getElementById('equalizer-container');
    elements.equalizerView = document.getElementById('equalizer-view');

    // MTP Device
    elements.mtpDeviceButton = document.getElementById('mtp-device-button');
    elements.mtpDevicePopup = document.getElementById('mtp-device-popup');
    elements.mtpDeviceName = document.getElementById('mtp-device-name');
    elements.mtpStorageUsed = document.getElementById('mtp-storage-used');
    elements.mtpStorageLabel = document.getElementById('mtp-storage-label');
    elements.mtpTransferQueueBtn = document.getElementById('mtp-transfer-queue-btn');
    elements.mtpEjectBtn = document.getElementById('mtp-eject-btn');
    elements.mtpBrowseStorageBtn = document.getElementById('mtp-browse-storage-btn');
}
