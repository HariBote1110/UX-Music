// uxmusic/src/renderer/js/virtual-scroller.js

export class VirtualScroller {
    container: HTMLElement;
    data: unknown[];
    renderItem: (item: unknown, index: number) => HTMLElement;
    itemHeight: number;
    buffer: number;
    sizer: HTMLElement;
    renderedItems: Map<number, HTMLElement>;
    scrollTimeout: number | null = null;

    constructor({ element, data, renderItem, itemHeight, buffer = 10 }: {
        element: HTMLElement;
        data: unknown[];
        renderItem: (item: unknown, index: number) => HTMLElement;
        itemHeight: number;
        buffer?: number;
    }) {
        if (!element || !data || !renderItem || !itemHeight) {
            throw new Error("VirtualScroller: Missing required constructor options.");
        }

        this.container = element;
        this.data = data;
        this.renderItem = renderItem;
        this.itemHeight = itemHeight;
        this.buffer = buffer;

        this.container.style.position = 'relative';
        this.container.style.overflowY = 'auto';

        // スクロール領域の高さを確保する要素
        // データ量に応じた高さ + 再生バー分の余白(CSS変数) を計算して設定
        this.sizer = document.createElement('div');
        this.sizer.style.position = 'absolute';
        this.sizer.style.top = '0';
        this.sizer.style.left = '0';
        this.sizer.style.width = '1px';
        this.sizer.style.height = `calc(${this.data.length * this.itemHeight}px + var(--footer-height, 0px))`;
        this.container.appendChild(this.sizer);

        this.renderedItems = new Map();

        this.onScroll = this.onScroll.bind(this);
        this.container.addEventListener('scroll', this.onScroll, { passive: true });

        requestAnimationFrame(() => {
            // 要素がDOMに接続されている場合のみ描画
            if (this.container.isConnected) {
                this.render();
            }
        });
    }

    onScroll() {
        if (!this.scrollTimeout) {
            this.scrollTimeout = requestAnimationFrame(() => {
                this.render();
                this.scrollTimeout = null;
            });
        }
    }

    render() {
        // コンテナがDOMに存在しない、または非表示の場合は処理をスキップ
        if (!this.container.isConnected || this.container.clientHeight === 0) {
            return;
        }

        const scrollTop = this.container.scrollTop;
        const containerHeight = this.container.clientHeight;

        const startIndex = Math.max(0, Math.floor(scrollTop / this.itemHeight) - this.buffer);
        const endIndex = Math.min(this.data.length - 1, Math.ceil((scrollTop + containerHeight) / this.itemHeight) + this.buffer);

        const visibleIndexes = new Set();
        for (let i = startIndex; i <= endIndex; i++) {
            visibleIndexes.add(i);
            if (!this.renderedItems.has(i)) {
                const itemData = this.data[i];
                const element = this.renderItem(itemData, i);
                element.style.position = 'absolute';
                element.style.transform = `translateY(${i * this.itemHeight}px)`;
                element.style.left = '0';
                element.style.right = '0';
                element.style.height = `${this.itemHeight}px`;

                this.container.appendChild(element);
                this.renderedItems.set(i, element);
            }
        }

        for (const [index, element] of this.renderedItems.entries()) {
            if (!visibleIndexes.has(index)) {
                element.remove();
                this.renderedItems.delete(index);
            }
        }
    }

    updateData(newData) {
        this.data = newData;
        const totalHeight = this.data.length * this.itemHeight;

        // 高さの更新 (再生バーの余白も考慮)
        this.sizer.style.height = `calc(${totalHeight}px + var(--footer-height, 0px))`;

        for (const element of this.renderedItems.values()) {
            element.remove();
        }
        this.renderedItems.clear();

        requestAnimationFrame(() => {
            if (this.container.isConnected) this.render();
        });
    }

    destroy() {
        this.container.removeEventListener('scroll', this.onScroll);

        // 明示的に要素を削除し、参照を解除する
        for (const element of this.renderedItems.values()) {
            element.remove();
        }
        this.renderedItems.clear();
        this.data = [];

        this.container.innerHTML = '';
        if (this.scrollTimeout) {
            cancelAnimationFrame(this.scrollTimeout);
        }
    }
}
