// src/renderer/js/ui/list-renderer.js

import { state, elements } from '../core/state.js';
import { playSong } from '../features/playback-manager.js';
import { setVisualizerTarget } from '../features/player.js';
import { VirtualScroller } from './virtual-scroller.js';
import { createSongItem } from './element-factory.js';
import { initColumnResizing } from './column-resizer.js';
import { showContextMenu } from './utils.js';
import { showModalAdvanced } from './modal.js';
import { getVisibleColumns, getGridTemplate, showColumnContextMenu } from './column-config.js';
import { updateGridStyle } from './column-resizer.js';
import { getWailsApp, musicApi } from '../core/bridge.js';
import { showNotification } from './notification.js';
const electronAPI = window.electronAPI;

type PlaylistAddSourceSong = {
    path?: string;
    duration?: number;
    artist?: string;
    title?: string;
    [key: string]: unknown;
};

type PlaylistAddPayloadSong = {
    path: string;
    duration: number;
    artist: string;
    title: string;
};

function playlistAddCount(result: unknown): number {
    if (Number.isFinite(Number(result))) {
        return Number(result);
    }
    if (result && typeof result === 'object') {
        const addedCount = (result as { addedCount?: unknown }).addedCount;
        return Number.isFinite(Number(addedCount)) ? Number(addedCount) : 0;
    }
    return 0;
}

export function playlistAddPayloadForSongs(playlistName: string, songs: PlaylistAddSourceSong[]) {
    return {
        playlistName,
        songs: songs
            .filter(song => typeof song.path === 'string' && song.path.length > 0)
            .map((song): PlaylistAddPayloadSong => ({
                path: song.path as string,
                duration: Number.isFinite(Number(song.duration)) ? Number(song.duration) : 0,
                artist: typeof song.artist === 'string' ? song.artist : '',
                title: typeof song.title === 'string' ? song.title : '',
            })),
    };
}

export async function addSongsToPlaylistFromMenu(playlistName: string, songs: PlaylistAddSourceSong[]): Promise<number> {
    const payload = playlistAddPayloadForSongs(playlistName, songs);
    if (!playlistName.trim() || payload.songs.length === 0) {
        showNotification('プレイリストへ追加できる曲がありません。', 3000);
        return 0;
    }
    try {
        const result = await musicApi.addSongsToPlaylist(payload);
        const added = playlistAddCount(result);
        if (added > 0) {
            showNotification(`${added}曲をプレイリスト「${playlistName}」に追加しました。`, 3000);
        } else {
            showNotification('すべての曲が既にプレイリストに存在します。', 3000);
        }
        return added;
    } catch (error) {
        showNotification(`プレイリストへの追加に失敗しました: ${(error as Error)?.message || String(error)}`, 4000);
        return 0;
    }
}

/**
 * 曲リストの共通ヘッダーHTMLを作成する（column-config に基づく動的生成）
 */
export function createListHeader() {
    const visibleCols = getVisibleColumns();
    const headerCells = visibleCols.map(col => {
        const content = col.label ? `<span>${col.label}</span>` : '';
        return `<div class="${col.cssClass}">${content}</div>`;
    }).join('\n            ');
    return `
        <div id="music-list-header">
            ${headerCells}
        </div>
    `;
}

/**
 * 曲アイテムのクリックイベントを処理する (再生または複数選択)
 */
function handleSongItemClick(e, song, index, songList, songItem) {
    if (e.metaKey || e.ctrlKey) {
        if (state.selectedSongIds.has(song.id)) {
            state.selectedSongIds.delete(song.id);
            songItem.classList.remove('selected');
        } else {
            state.selectedSongIds.add(song.id);
            songItem.classList.add('selected');
        }
    } else {
        playSong(index, songList);
    }
}

function deleteSongsFromLibrary(songs) {
    console.log('[DeleteSongs] context action invoked', songs);

    const paths = (songs || [])
        .map((s) => {
            if (s?.path) return s.path;
            const resolved = s?.id ? state.libraryById.get(s.id) : null;
            return resolved?.path || '';
        })
        .filter(Boolean);
    console.log('[DeleteSongs] resolved paths:', paths);
    if (paths.length === 0) {
        console.warn('[DeleteSongs] No valid file paths found in selected songs');
        return;
    }

    const targetCount = paths.length;
    const message = targetCount === 1
        ? '選択した1曲をライブラリから削除します。'
        : `選択した${targetCount}曲をライブラリから削除します。`;

    showModalAdvanced({
        title: '曲を削除',
        message,
        requireInput: false,
        okText: '削除',
        cancelText: 'キャンセル',
        onOk: () => {
            const wailsApp = getWailsApp();
            if (!wailsApp?.DeleteSongs) {
                console.error('[DeleteSongs] App.DeleteSongs is not available on Wails bindings');
                return;
            }

            console.log('[DeleteSongs] invoking backend DeleteSongs');
            let pendingWarnTimer = null;
            let deletePromise;
            try {
                deletePromise = wailsApp.DeleteSongs(paths, false);
            } catch (err) {
                console.error('[DeleteSongs] invocation threw:', err);
                return;
            }
            pendingWarnTimer = setTimeout(() => {
                console.warn('[DeleteSongs] backend call is still pending after 5s');
            }, 5000);

            Promise.resolve(deletePromise)
                .then((deletedPaths) => {
                    clearTimeout(pendingWarnTimer);
                    console.log('[DeleteSongs] backend result:', deletedPaths);
                    const normalizedDeleted = Array.isArray(deletedPaths) ? deletedPaths : paths;
                    if (window.runtime?.EventsEmit && normalizedDeleted.length > 0) {
                        window.runtime.EventsEmit('songs-deleted', normalizedDeleted);
                    }
                    if (wailsApp?.LoadLibrary) {
                        // Always refresh from persisted library in Wails to avoid stale in-memory state.
                        wailsApp.LoadLibrary();
                    }
                })
                .catch((err) => {
                    clearTimeout(pendingWarnTimer);
                    console.error('[DeleteSongs] failed:', err);
                });
        }
    });
}

/**
 * VirtualScroller をセットアップし、曲リストを描画する
 */
export function setupSongListScroller(listElement, songList, options: { contextView?: string; playlistName?: string | null; initialScrollTop?: number; saveScrollPosition?: (top: number) => void } = {}) {
    const {
        contextView = 'library',
        playlistName = null,
        initialScrollTop = 0,
        saveScrollPosition // detail-renderer から渡されるコールバック
    } = options;

    /**
     * VirtualScroller が各アイテムを描画するための関数
     */
    const renderItem = (song, index) => {
        const songItem = createSongItem(song, index, songList, {
            groupAlbumArt: true
        });

        // 選択状態の復元
        if (state.selectedSongIds.has(song.id)) {
            songItem.classList.add('selected');
        }

        // ▼▼▼ 修正箇所 ▼▼▼
        const currentPlayingSong = state.playbackQueue[state.currentSongIndex];
        const currentIdentifier = currentPlayingSong?.id || currentPlayingSong?.path;
        const rowIdentifier = song?.id || song?.path;
        if (currentPlayingSong && currentIdentifier && rowIdentifier && currentIdentifier === rowIdentifier) {
            songItem.classList.add('playing');

            // このアイテムがDOMに挿入された時点でターゲットに設定
            // (visualizer.js 側で同一要素チェックを行う)
            setVisualizerTarget(songItem);
        }
        // ▲▲▲ 修正箇所 ▲▲▲

        // イベントリスナー
        songItem.addEventListener('click', (e) => handleSongItemClick(e, song, index, songList, songItem));

        songItem.addEventListener('contextmenu', (e) => {
            e.preventDefault();

            if (playlistName && typeof saveScrollPosition === 'function') {
                saveScrollPosition(listElement.scrollTop);
            }

            let songsForMenu = [song];
            if (state.selectedSongIds.size > 0 && state.selectedSongIds.has(song.id)) {
                songsForMenu = songList.filter(s => state.selectedSongIds.has(s.id));
            }

            if (typeof window.go !== 'undefined') {
                // Wails 環境: JavaScript ベースのコンテキストメニュー
                const menuItems = [
                    {
                        label: '再生',
                        action: () => playSong(index, songList)
                    },
                    {
                        label: songsForMenu.length > 1 ? `ライブラリから削除 (${songsForMenu.length}曲)` : 'ライブラリから削除',
                        action: () => deleteSongsFromLibrary(songsForMenu)
                    }
                ];

                // プレイリストがある場合のみサブメニューを追加
                if (state.playlists && state.playlists.length > 0) {
                    const playlistSubmenu = (state.playlists as Record<string, unknown>[]).map(playlist => ({
                        label: playlist.name as string,
                        action: () => void addSongsToPlaylistFromMenu(String(playlist.name ?? ''), songsForMenu)
                    }));
                    (menuItems as unknown[]).push({
                        label: 'プレイリストに追加',
                        submenu: playlistSubmenu
                    });
                }

                showContextMenu(e.pageX, e.pageY, menuItems);
            } else {
                // Electron 環境: メインプロセスにメニュー表示を委譲
                electronAPI.send('show-song-context-menu', {
                    songs: songsForMenu,
                    context: { view: contextView, playlistName }
                });
            }
        });

        window.observeNewArtworks(songItem); // Lazy-load 用
        return songItem;
    };

    // VirtualScroller の初期化
    const scroller = new VirtualScroller({
        element: listElement,
        data: songList,
        itemHeight: 56,
        renderItem: renderItem,
    });

    if (initialScrollTop > 0) {
        requestAnimationFrame(() => {
            listElement.scrollTop = initialScrollTop;
        });
    }

    // ▼▼▼ 削除（renderItem 内に移動したため） ▼▼▼
    // requestAnimationFrame(() => {
    //     const playingItem = listElement.querySelector('.song-item.playing');
    //     if (playingItem) {
    //         setVisualizerTarget(playingItem);
    //     }
    // });
    // ▲▲▲ 削除 ▲▲▲

    return scroller;
}

/**
 * リストヘッダーの列サイズ変更機能を初期化する
 */
export function initListHeaderResizing(viewWrapper) {
    // 可視列に基づいた初期Gridスタイルを適用
    updateGridStyle(getGridTemplate());

    const headerEl = viewWrapper.querySelector('#music-list-header');
    if (headerEl) {
        initColumnResizing(headerEl);

        // ヘッダー右クリックで列の表示/非表示メニューを表示
        headerEl.addEventListener('contextmenu', (e) => {
            // 子要素のコンテキストメニューも捕捉
            e.preventDefault();
            e.stopPropagation();
            showColumnContextMenu(e, () => {
                // コールバック: ビューを再描画して列変更を反映
                import('../ui/ui-manager.js').then(mod => mod.renderCurrentView());
            });
        });
    }
}
