// src/renderer/js/ui/element-factory.js
import { formatTime, checkTextOverflow, resolveArtworkPath, formatSongTitle, escapeHtml } from './utils.js';
import { DEFAULT_ARTWORK_URL } from '../constants/default-artwork.js';
import { state } from '../core/state.js';
import { createPlaylistArtwork } from './playlist-artwork.js';
import { getVisibleColumns } from './column-config.js';

const pendingMarqueeWrappers = new Set();
let marqueeFlushFrameId = null;

function scheduleMarqueeMeasurement(songItem) {
    songItem.querySelectorAll('.marquee-wrapper').forEach((wrapper) => {
        pendingMarqueeWrappers.add(wrapper);
    });

    if (marqueeFlushFrameId) {
        return;
    }

    marqueeFlushFrameId = requestAnimationFrame(() => {
        pendingMarqueeWrappers.forEach((wrapper) => checkTextOverflow(wrapper));
        pendingMarqueeWrappers.clear();
        marqueeFlushFrameId = null;
    });
}

function findArtworkFromSongIds(songIds = []) {
    for (const songId of songIds) {
        const song = state.libraryById.get(songId);
        if (song?.artwork) {
            return song.artwork;
        }
    }
    return null;
}

export function songPlayCountValue(song, playCounts = state.playCounts) {
    const path = typeof song?.path === 'string' ? song.path : '';
    const localCount = path ? playCounts?.[path]?.count : undefined;
    if (Number.isFinite(Number(localCount))) {
        return Number(localCount);
    }
    const syncCount = song?.syncPlayCount?.count;
    if (Number.isFinite(Number(syncCount))) {
        return Number(syncCount);
    }
    return 0;
}

export function createSongItem(song, index, songList, options: { groupAlbumArt?: boolean } = {}) {
    const { groupAlbumArt = true } = options;
    const songIdentifier = song.id || song.path || '';
    const songItem = document.createElement('div');
    songItem.className = `song-item${song.syncAvailability === 'remote' ? ' remote-song' : ''}`;
    songItem.dataset.songPath = song.path || '';
    songItem.dataset.songId = songIdentifier;

    let showArt = true;
    let isGrouped = false;
    let isLastOfGroup = false;

    if (groupAlbumArt && song.albumKey) {
        const prevSong = songList[index - 1];
        const isFirstOfGroup = !prevSong || prevSong.albumKey !== song.albumKey;
        if (!isFirstOfGroup) {
            const nextSong = songList[index + 1];
            isLastOfGroup = !nextSong || nextSong.albumKey !== song.albumKey;
            showArt = false;
            isGrouped = true;
        }
    }

    // Light Flightモードでもimgタグは常に生成し、CSSで表示を制御する
    const artworkHTML = `<img src="${DEFAULT_ARTWORK_URL}" class="artwork-small lazy-load" alt="artwork">`;

    const hiResIconHTML = song.isHiRes ? `
        <svg class="hires-icon" width="24" height="14" viewBox="0 0 24 14" xmlns="http://www.w3.org/2000/svg">
            <rect x="0.5" y="0.5" width="23" height="13" rx="2" stroke="#D9A300" stroke-opacity="0.8" fill="none"/>
            <text x="12" y="10" font-family="Arial, sans-serif" font-size="9" font-weight="bold" fill="#D9A300" text-anchor="middle">HR</text>
        </svg>
    ` : '';

    // 可視列に基づいてHTMLを動的に構築
    const columnHTMLMap = {
        index: `<div class="song-index">
            <span class="song-number">${index + 1}</span>
            <div class="playing-indicator">
                <div class="playing-indicator-bar"></div><div class="playing-indicator-bar"></div><div class="playing-indicator-bar"></div>
                <div class="playing-indicator-bar"></div><div class="playing-indicator-bar"></div><div class="playing-indicator-bar"></div>
            </div>
            <img src="./assets/icons/static-visualizer.svg" class="static-visualizer-img" alt="Playing">
        </div>`,
        artwork: `<div class="song-artwork-col">${artworkHTML}</div>`,
        title: `<div class="song-title"><div class="marquee-wrapper"><div class="marquee-content"><span>${escapeHtml(formatSongTitle(song.title))}</span></div></div>${remoteAvailabilityBadgeHTML(song)}</div>`,
        artist: `<div class="song-artist"><div class="marquee-wrapper"><div class="marquee-content"><span>${escapeHtml(song.artist)}</span></div></div></div>`,
        album: `<div class="song-album"><div class="marquee-wrapper"><div class="marquee-content"><span>${escapeHtml(song.album)}</span></div></div></div>`,
        hires: `<div class="song-hires">${hiResIconHTML}</div>`,
        duration: `<div class="song-duration"><span>${formatTime(song.duration || 0)}</span></div>`,
        playCount: `<div class="song-play-count">${songPlayCountValue(song)}</div>`,
    };

    const visibleCols = getVisibleColumns();
    songItem.innerHTML = visibleCols.map(col => columnHTMLMap[col.key] || '').join('\n        ');

    const artworkCol = songItem.querySelector('.song-artwork-col') as HTMLElement | null;
    const artworkImg = songItem.querySelector('.artwork-small') as HTMLImageElement | null;

    if (isGrouped) {
        if (artworkImg) artworkImg.style.visibility = 'hidden';

        const verticalLine = document.createElement('div');
        verticalLine.style.position = 'absolute';
        verticalLine.style.left = '50%';
        verticalLine.style.width = '1px';
        verticalLine.style.backgroundColor = 'var(--text-muted)';
        verticalLine.style.transform = 'translateX(-50%)';

        if (isLastOfGroup) {
            verticalLine.style.top = '0';
            verticalLine.style.height = '50%';

            const horizontalLine = document.createElement('div');
            horizontalLine.style.position = 'absolute';
            horizontalLine.style.top = '50%';
            horizontalLine.style.left = '50%';
            horizontalLine.style.width = '50%';
            horizontalLine.style.height = '1px';
            horizontalLine.style.backgroundColor = 'var(--text-muted)';

            artworkCol.appendChild(horizontalLine);
        } else {
            verticalLine.style.top = '0';
            verticalLine.style.height = '100%';
        }
        artworkCol.appendChild(verticalLine);
    }

    if (artworkImg) {
        if (showArt) {
            const album = state.albums.get(song.albumKey);

            let artwork = resolveSongArtworkForList(song);
            if (!artwork && song.album !== 'Unknown Album') {
                if (song.artwork) {
                    artwork = song.artwork;
                } else if (album) {
                    if (album.artwork) {
                        artwork = album.artwork;
                    } else {
                        artwork = findArtworkFromSongIds(album.songIds as string[]);
                    }
                }
            }

            artworkImg.classList.add('lazy-load');
            artworkImg.dataset.src = song.syncAvailability === 'remote' ? DEFAULT_ARTWORK_URL : resolveArtworkPath(artwork, true);
        }
    }

    scheduleMarqueeMeasurement(songItem);

    return songItem;
}

export function remoteAvailabilityBadgeText(song) {
    return song?.syncAvailability === 'remote' ? 'DL可能' : '';
}

function remoteAvailabilityBadgeHTML(song) {
    const text = remoteAvailabilityBadgeText(song);
    return text ? `<span class="sync-availability-badge">${escapeHtml(text)}</span>` : '';
}

export function resolveSongArtworkForList(song) {
    if (song?.syncAvailability === 'remote') {
        return DEFAULT_ARTWORK_URL;
    }
    return song?.artwork || null;
}

export function createQueueItem(song, isPlaying, queueIndex) {
    const queueItem = document.createElement('div');
    queueItem.className = `queue-item ${isPlaying ? 'playing' : ''}`;
    queueItem.dataset.songPath = song.path;
    queueItem.dataset.queueIndex = String(queueIndex);
    // Reorder DnD is not implemented; draggable breaks reliable click-to-play in WKWebView/Wails.
    queueItem.draggable = false;

    queueItem.innerHTML = `
        <img src="${DEFAULT_ARTWORK_URL}" class="artwork-small" alt="artwork">
        <div class="queue-item-info">
            <div class="queue-item-title marquee-wrapper">
                <div class="marquee-content">
                    <span>${escapeHtml(formatSongTitle(song.title))}</span>
                </div>
            </div>
            <div class="queue-item-artist marquee-wrapper">
                <div class="marquee-content">
                    <span>${escapeHtml(song.artist)}</span>
                </div>
            </div>
        </div>
    `;

    const artworkImg = queueItem.querySelector('.artwork-small') as HTMLImageElement | null;
    const album = state.albums.get(song.albumKey);
    let finalArtwork = song.artwork;
    if (!finalArtwork && song.album !== 'Unknown Album') {
        finalArtwork = album ? album.artwork : null;
    }
    if (artworkImg) {
        artworkImg.src = resolveArtworkPath(finalArtwork, true);
        artworkImg.onload = () => window.recordArtworkLoadTime?.(performance.now());
    }

    return queueItem;
}


export function createAlbumGridItem(key, album) {
    const albumItem = document.createElement('div');
    albumItem.className = 'album-grid-item';

    albumItem.innerHTML = `
        <img src="${DEFAULT_ARTWORK_URL}" class="album-artwork lazy-load" alt="${escapeHtml(album.title)}">
        <div class="album-title marquee-wrapper">
            <div class="marquee-content">
                <span>${escapeHtml(album.title || 'Unknown Album')}</span>
            </div>
        </div>
        <div class="album-artist marquee-wrapper">
            <div class="marquee-content">
                <span>${escapeHtml(album.artist || 'Unknown Artist')}</span>
            </div>
        </div>
    `;

    const artworkImg = albumItem.querySelector('.album-artwork') as HTMLImageElement | null;
    let artworkToUse = album.artwork;
    if (!artworkToUse) {
        artworkToUse = findArtworkFromSongIds(album?.songIds as string[]);
    }
    if (artworkImg) {
        artworkImg.dataset.src = resolveArtworkPath(artworkToUse, false);
        artworkImg.onload = () => window.recordArtworkLoadTime?.(performance.now());
    }

    return albumItem;
}

export function createArtistGridItem(artist) {
    const artistItem = document.createElement('div');
    artistItem.className = 'artist-grid-item';

    artistItem.innerHTML = `
        <img src="${DEFAULT_ARTWORK_URL}" class="artist-artwork lazy-load" alt="${escapeHtml(artist.name)}">
        <div class="artist-name marquee-wrapper">
            <div class="marquee-content">
                <span>${escapeHtml(artist.name)}</span>
            </div>
        </div>
    `;

    const artworkImg = artistItem.querySelector('.artist-artwork') as HTMLImageElement | null;
    if (artworkImg) {
        artworkImg.dataset.src = resolveArtworkPath(artist.artwork, false);
        artworkImg.onload = () => window.recordArtworkLoadTime?.(performance.now());
    }

    return artistItem;
}

export function createPlaylistGridItem(playlist) {
    const playlistItem = document.createElement('div');
    playlistItem.className = 'playlist-grid-item';

    playlistItem.innerHTML = `
        <div class="playlist-artwork-container"></div>
        <div class="playlist-title marquee-wrapper">
            <div class="marquee-content">
                <span>${escapeHtml(playlist.name)}</span>
            </div>
        </div>
    `;

    const artworkContainer = playlistItem.querySelector('.playlist-artwork-container');
    const resolver = (artwork) => resolveArtworkPath(artwork, false);
    createPlaylistArtwork(artworkContainer, playlist.artworks, resolver);

    return playlistItem;
}
