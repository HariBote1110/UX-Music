/** MTP 転送画面の HTML（旧 components/mtp-transfer.html） */
export function getMtpTransferViewHtml() {
    return `<div class="view-header">
    <h1>デバイスへ転送</h1>
    <div class="header-actions">
        <span id="mtp-transfer-device-name">デバイス名</span>
        <button id="mtp-transfer-browse-btn" type="button" class="header-button">📂 ディレクトリを見る</button>
        <button id="mtp-transfer-close-btn" type="button" class="header-button">閉じる</button>
    </div>
</div>

<div class="sync-section">
    <div class="sync-header">
        <h3>📋 未転送曲を検出</h3>
        <button id="mtp-detect-untransferred-btn" type="button" class="primary-button">
            🔍 スキャン開始
        </button>
    </div>
    <div id="mtp-sync-status" class="sync-status"></div>
    <div id="mtp-untransferred-list" class="untransferred-list hidden">
    </div>
    <div id="mtp-sync-actions" class="sync-actions hidden">
        <button id="mtp-transfer-all-btn" type="button" class="primary-button">
            📤 すべて転送
        </button>
        <span id="mtp-untransferred-count"></span>
    </div>
</div>

<div class="transfer-content-wrapper mtp-transfer-inner">
    <div class="transfer-pane source-pane">
        <h3>ライブラリ</h3>
        <div id="mtp-transfer-source-list" class="transfer-list-container">
            <p>転送する曲を読み込み中...</p>
        </div>
    </div>

    <div class="transfer-actions">
        <button id="mtp-transfer-start-btn" type="button" title="選択した項目を転送">
            &gt;&gt;
        </button>
    </div>

    <div class="transfer-pane device-pane">
        <h3>デバイス</h3>
        <div id="mtp-transfer-device-list" class="transfer-list-container">
            <p>デバイスのファイルリストを読み込み中...</p>
        </div>
    </div>
</div>
<div id="mtp-transfer-progress-container" class="transfer-progress-container hidden">
    <p id="mtp-transfer-progress-label">転送中...</p>
    <progress id="mtp-transfer-progress-bar" value="0" max="100"></progress>
</div>`;
}

/**
 * @param {HTMLElement} container
 */
export function renderMtpTransferView(container) {
    container.innerHTML = `<div id="mtp-transfer-view" class="mtp-transfer-view-inner">${getMtpTransferViewHtml()}</div>`;
}
