# 開発進捗ログ (progress.md)

## 2026年6月10日

### UX Sync snapshot重複曲数の補正

- **課題**:
    - Air 側に過去の重複 import で同じ実ファイルパスを指す library 行が複数残っていると、mini 側の自動同期トーストで既存曲数が実ライブラリより大きく表示されていた。
- **実装内容**:
    - `/sync/library/snapshot` 生成時に同じ `path` の track を代表1件へ重複排除し、`count` も重複排除後の件数を返すようにした。
    - `path` が空の特殊ケースでは `syncSourceDeviceId` / `syncSourceTrackId` を重複排除キーとして使い、同期元IDが同じ曲を重複して公開しないようにした。
- **検証**:
    - `go test ./server -run TestSyncLibrarySnapshotDeduplicatesRepeatedLibraryPaths -count=1`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-34c` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-37c` に更新。

### UX Sync 再生回数の全件メタデータ同期

- **課題**:
    - リアルタイム再生イベントは届いていても、端末ごとの `playcounts-base` がズレていると、Air / mini 間で基準再生回数がずれたままになっていた。
    - peer の `syncPlayCount` は総再生回数なのに、そのまま `playcounts-base` へ入れると、ローカル `sync-play-events` の投影分がさらに加算されて二重計上されていた。
- **実装内容**:
    - `AutoSyncPairedDevices()` が `LibraryHost` peer の snapshot を取得した時に、`track.syncPlayCount` をローカル同一曲へ全件反映するようにした。
    - 突合は `syncSourceDeviceId` / `syncSourceTrackId` を優先し、未取得またはローカル同一曲では `syncSongMatchKey` で反映するようにした。
    - 反映時は音源やジャケットを取得せず、`syncPlayCount` からローカル `sync-play-events` の投影数を差し引いた値を `playcounts-base` に保存するようにした。
- **検証**:
    - `go test ./server -run 'TestAutoSyncPairedDevicesAppliesRemotePlayCountSnapshotWithoutAssetPull|TestPullSyncLibraryAssetsUpdatesPlayCountWhenImportedTrackAlreadyExists|TestIncrementPlayCountKeepsImportedSyncPlayCountBase' -count=1`
    - `go test ./server -run 'TestIncrementPlayCountImmediateSyncSkipsHeavyLibraryWork|TestAutoSyncPairedDevicesPushesLocalPlayEventsToReachablePeer|TestSyncPlayCountsConvergeAcrossBidirectionalMetadataMatchedEvents' -count=1`
    - `go test ./server -run TestApplySyncPlayCountSnapshotSubtractsLocalEventProjectionFromBase -count=1`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-34b` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-37b` に更新。

### UX Sync 再生時即時同期

- **課題**:
    - 通信可能な状態でも、再生回数は定期 AutoSync まで peer へ届かず、Air / mini 間で「再生した直後の反映」が遅れていた。
    - 再生直後の即時同期に総合 AutoSync を使うと、`/sync/library/snapshot`、pull、ジャケット補完まで走り、再生回数反映には重すぎた。
- **実装内容**:
    - `IncrementPlayCount()` で `PlayEvent` を保存し `playcounts` を更新した直後に、再生イベント専用の軽量同期をバックグラウンドで即時スケジュールするようにした。
    - 連続再生で同期ジョブが重なり続けないよう、実行中の追加要求は pending として畳み、完了後にもう一度同期を試すようにした。
    - 即時同期を再生イベント専用の軽量 flush に分離し、再生直後は `/sync/library/events` だけを実行するようにした。
- **検証**:
    - `go test ./server -run 'TestIncrementPlayCountTriggersImmediateSyncWhenPeerReachable|TestIncrementPlayCountRecordsLocalSyncPlayEvent|TestIncrementPlayCountKeepsImportedSyncPlayCountBase' -count=1`
    - `go test ./server -run 'TestAutoSyncPairedDevicesPushesLocalPlayEventsToReachablePeer|TestSyncPlayCountsConvergeAcrossBidirectionalMetadataMatchedEvents' -count=1`
    - `go test ./server -run TestIncrementPlayCountImmediateSyncSkipsHeavyLibraryWork -count=1`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-33b` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-36b` に更新。

### UX Sync 再生回数メタデータ先行同期

- **課題**:
    - ジャケットは remote catalog / pull 経由で取得できていたが、再生回数は音源 push 時の metadata に偏っており、Air 側では既存曲や未取得 remote 曲の再生回数が mini 側と大きくズレていた。
    - 既に import 済みの曲へ push が再送された場合、音源重複は skipped になるが `syncPlayCount` も破棄されていた。
    - Air 側で再生した瞬間、`playcounts-base` に入っていない同期済み再生回数が `base + sync-play-events` の再計算で消え、Air 側ローカル回数だけに戻って見えていた。
- **実装内容**:
    - `/sync/library/snapshot` の各 track に、送信側 `playcounts` から正規化した `syncPlayCount` を同梱するようにした。
    - `PullSyncLibraryAssets()` は既に取得済みの同期曲を再ダウンロードせず、snapshot の `syncPlayCount` だけを実保存パスの `playcounts` へ反映するようにした。
    - pull で新規取得した曲にも import 後に `syncPlayCount` を反映し、`library.json` には転送用フィールドを残さないようにした。
    - `/sync/library/import` の重複 skipped 経路でも、既存保存パスへ `syncPlayCount` だけを反映するようにした。
    - `playcounts-base` migration 済みの環境では、受信した `syncPlayCount` を `playcounts-base` にも反映し、その後の再生時再計算で同期済み回数が消えないようにした。
    - renderer の再生回数表示は local path の `playCounts` を優先し、未取得 remote 曲では `song.syncPlayCount.count` を fallback として表示するようにした。
- **検証**:
    - `go test ./server -run 'TestSyncLibrarySnapshotRequiresTokenAndReturnsLibraryTracks|TestPullSyncLibraryAssetsDownloadsRemoteTrackIntoManagedLibrary|TestPullSyncLibraryAssetsUpdatesPlayCountWhenImportedTrackAlreadyExists' -count=1`
    - `go test ./server -run TestSyncLibraryImportUpdatesPlayCountWhenTrackAlreadyExists -count=1`
    - `go test ./server -run TestIncrementPlayCountKeepsImportedSyncPlayCountBase -count=1`
    - `npm test --prefix src/renderer -- --run js/ui/sync-availability.test.ts`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-32c` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-35c` に更新。

### UX Sync 実環境バグ修正（相互ペアリング・重複表示・ジャケット取得）

- **課題**:
    - 手動ペアリング確定後、開始側の `baseUrl` が受信側へ保存されず、片方向だけ既知 peer が残る状態になり得た。
    - 統一ライブラリの再読み込みで remote 曲を表示した後、同一曲をローカル取得しても renderer の path ベース merge が stale remote 曲を残していた。
    - タップDL / pull 取得では音源のみ保存され、remote catalog の `syncArtwork` 情報に対応する実ジャケットファイルが取得されていなかった。
- **実装内容**:
    - `/sync/pairing/start` / `/sync/pairing/confirm` の payload に開始側 identity と到達可能 `baseUrl` を追加し、受信側 known peer 保存時は payload の `baseUrl` を優先するようにした。旧 payload でも従来どおり 200 応答できる互換性は維持した。
    - renderer のライブラリ反映処理を `mergeSongsIntoLibrary` に切り出し、同一曲 match key では local 曲を優先して stale remote 曲を置換し、インデックスを再構築するようにした。
    - `downloadSyncTrackAsset` で音源保存後・library upsert 前に `/sync/assets/{trackId}/artwork` を取得し、成功時は `artwork` 参照を保存するようにした。ジャケット取得失敗や未検出は音源取得を失敗扱いにしない。
    - `syncMissingArtworkFromPeer` は track 単位の artwork 取得エラーで全体を中断せず、後続 track の補完を続行するようにした。
- **検証**:
    - `go test ./server -run 'TestSyncPairingConfirmStoresInitiatorKnownPeerFromPayload|TestStartSyncPairingCallsRemotePeerWithLocalDeviceID|TestConfirmSyncPairingStoresRemoteIssuedTokenForRemoteDevice|TestSyncPairingStartAndConfirmIssuesToken' -count=1`
    - `npm test --prefix src/renderer -- --run js/core/library-model.test.ts js/ui/sync-availability.test.ts js/features/playback-manager.test.ts`
    - `go test ./server -run 'TestDownloadSyncTrackImportsRemoteCatalogTrack|TestSyncMissingArtworkFromPeerContinuesAfterTrackError|TestPullSyncLibraryAssetsDownloadsRemoteTrackIntoManagedLibrary' -count=1`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-31b` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-34b` に更新。

### UX Sync 手動ペアリング導線

- **課題**:
    - mDNS が使えない／不安定な環境では、発見一覧からペアリングを開始できず、直接到達できる peer とも接続できなかった。
- **実装内容**:
    - UX Sync 専用設定画面の `端末` タブへ IP / ホスト名と任意ポートの手動入力欄を追加した。
    - `manualSyncPeerBaseUrl` と `startManualSyncPairing` を追加し、手動入力から baseURL を組み立てて既存の6桁コード確認ペアリングフローへ流せるようにした。
- **検証**:
    - `npm test --prefix src/renderer -- --run js/features/ux-sync-settings.test.ts`
    - `go test ./... -count=1`
    - `npm test --prefix src/renderer`
    - `npm run typecheck --prefix src/renderer`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-31a` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-34a` に更新。

### mDNS TXT 255バイト制限の緊急修正

- **課題**:
    - mDNS TXT の `capabilities=` が full capability set で 255 バイトを超え、zeroconf の広告送信が失敗して UX Sync の相互発見が効かなくなっていた。
- **実装内容**:
    - `BuildMDNSText` から `capabilities` 行を外し、mDNS TXT を `deviceId` / `displayName` / `protocolVersion` / `schemaVersion` / `roles` の軽量ヒントに限定した。
    - capability は reachableBaseUrl probe 後の `/sync/identity` response から取得する方針を protocol 文書へ明記した。
- **検証**:
    - `go test ./internal/uxsync ./server -run 'TestBuildMDNSText|TestSyncMDNSAdvertiseInfo_usesHostIdentity' -count=1`
    - `go test ./... -count=1`
    - `npm test --prefix src/renderer`
    - `npm run typecheck --prefix src/renderer`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-30b` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-33b` に更新。

### UX Sync ポータブル MP3 キャッシュ

- **課題**:
    - Air など容量制約のある portable client でも、pull / タップDL / prefetch / selective 自動同期は原本を取得しており、push 側だけにあった MP3 320kbps 変換を活かせなかった。
- **実装内容**:
    - `/sync/assets/{trackId}/file?encoding=mp3_320` を追加し、元が非 MP3 の曲は `syncOpenMP3Stream` で MP3 320kbps として配信するようにした。
    - 元が MP3 の曲は再変換せず原本配信し、変換失敗時は原本フォールバックせずエラーにするようにした。
    - `syncPreferredFormat` 設定を追加し、`mp3_320` かつ peer が `library.transcode.mp3-320.v1` を広告する場合だけ取得 URL に `encoding=mp3_320` を付けるようにした。
    - pull 取込曲へ `syncTransferEncoding: "mp3_320"` と `audioBitrateKbps: 320` を保存し、UX Sync 設定の `保存` タブへ優先フォーマット選択を追加した。
- **検証**:
    - `go test ./server -run 'TestSyncAssetFileServesMP3320EncodingWhenRequested|TestSyncAssetFileKeepsOriginalMP3WhenMP3320Requested|TestSyncAssetFileServesOriginalFileByTrackID|TestSyncAssetFileFailsMP3320EncodingWithoutOriginalFallback|TestPullSyncLibraryAssetsRequestsPreferredMP3320WhenPeerSupportsIt|TestPullSyncLibraryAssetsFallsBackToOriginalWhenPeerLacksMP3320Capability|TestPullSyncLibraryAssetsKeepsOriginalWhenPreferredFormatIsOriginal|TestSyncSongMatchKeyIgnoresTransferredFormat' -count=1`
    - `npm test --prefix src/renderer -- --run js/features/ux-sync-settings.test.ts`
    - `go test ./... -count=1`
    - `npm test --prefix src/renderer`
    - `npm run typecheck --prefix src/renderer`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-30a` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-33a` に更新。

## 2026年6月9日

### safe-media Windows絶対パス復元の修正

- **課題**:
    - `/safe-media/` のデコード処理が Windows ドライブレター付き絶対パスを `/C:/...` のように変換し、Windows では `filepath.IsAbs` が失敗して再生が Forbidden になり得た。
- **実装内容**:
    - `decodeSafeMediaPath` で Windows ドライブレター、既存の先頭スラッシュ、相対パスを分けて候補パスを作るようにした。
    - Windows ドライブレター付きパスは先頭 separator を追加せず、安全な絶対パスとして扱うようにした。
- **検証**:
    - `go test . -run 'TestDecodeSafeMediaPathKeepsWindowsDriveAbsolute|TestDecodeSafeMediaPathKeepsPosixAbsolutePath|TestAssetHandlerServesRegisteredSafeMediaWithReservedCharacters' -count=1`
    - `go test ./... -count=1`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-29c` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-32c` に更新。

### Gemini Code Assist レビュー指摘の実害修正

- **課題**:
    - `randomBytes` が `crypto/rand.Read` 失敗時に時刻文字列へフォールバックし、ペアリング secret の推測可能性があった。
    - `DiscoverMDNS` が entries channel close を検知せず、closed channel から nil を受け続ける可能性があった。
    - `/safe-artwork/` handler が escaped path を `ResolveArtworkPath` へ渡し、空白入りファイル名の解決を壊し得た。
    - `formatInt64` の自作変換が `math.MinInt64` でオーバーフローしていた。
- **実装内容**:
    - `crypto/rand` 失敗時のフォールバックを廃止し、panic で停止するようにした。
    - `DiscoverMDNS` の `entries` 受信で `ok` を確認し、close 後は `entries=nil` として select 対象から外すようにした。
    - `/safe-artwork/` は unescaped の `r.URL.Path` から prefix を外して artwork resolver へ渡すようにした。
    - `formatInt64` を `strconv.FormatInt(value, 10)` に置き換えた。
- **検証**:
    - `go test . -run 'TestAssetHandlerServesSafeArtworkWithEscapedSpace|TestAssetHandlerRejectsSafeArtworkTraversal|TestAssetHandlerServesRegisteredSafeMediaWithReservedCharacters' -count=1`
    - `go test ./internal/uxsync -run 'TestFormatInt64HandlesMinInt64|TestPruneAcknowledgedOutbox' -count=1`
    - `go test ./server -run 'TestSyncLibraryEvents|TestSyncIdentity|TestStartSyncPairing' -count=1`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-29b` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-32b` に更新。

### UX Sync Phase 5.16 スマートキャッシュと容量ポリシー

- **課題**:
    - 接続時の自動 pull が全曲ミラー前提で、持ち運び端末向けの選択的キャッシュや容量不足時の整理ができなかった。
- **実装内容**:
    - `syncCachePolicy` を追加し、既定 `mirror` では現行どおり全曲 pull、`selective` では最近再生 remote 曲とキュー先読みだけを取得するようにした。
    - `recentRemoteSyncTrackRefs` と `PrefetchSyncTracks` を追加し、playcounts history と remote catalog から先読み対象を決定できるようにした。
    - selective かつ空き容量閾値未満では、最終アクセスが最も古い同期取得音源をファイルと `library.json` から削除する LRU 処理を追加した。
    - renderer に cache policy の正規化・選択肢、キュー先読み refs 生成、`PrefetchSyncTracks` bridge 呼び出しを追加した。
- **検証**:
    - `go test ./server -run 'TestAutoSyncPairedDevicesSelective|TestAutoSyncPairedDevicesMirrorPolicy|TestRecentRemoteSyncTrackRefs|TestPrefetchSyncTracks|TestSelectiveCachePrunes|TestMirrorCachePolicyDoesNotPrune|TestDownloadSyncTrack' -count=1`
    - `npm test --prefix src/renderer -- --run js/features/ux-sync-settings.test.ts js/features/playback-manager.test.ts`
    - `npm run typecheck --prefix src/renderer`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-29a` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-32a` に更新。

### UX Sync Phase 5.15 シームレスDL再生

- **課題**:
    - 統一ライブラリビューで `DL可能` と表示される remote 曲は一覧には見えるが、再生操作ではまだ取得・再生できなかった。
- **実装内容**:
    - `DownloadSyncTrack(sourceDeviceId, sourceTrackId)` を追加し、`sync-remote-catalog` の該当 track と既知 peer/token を使って対象曲だけを取得し、`SyncLibrary` へ import できるようにした。
    - renderer の remote 曲再生フローを、単曲DL、統一ライブラリ再取得、local 曲として再生へ遷移する流れに変更した。
    - peer 未到達や token 不足などの DL 失敗時はエラー通知を出し、再生へ入らないようにした。
- **検証**:
    - `go test ./server -run 'TestDownloadSyncTrack' -count=1`
    - `npm test --prefix src/renderer -- --run js/features/playback-manager.test.ts`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-28a` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-31a` に更新。

### UX Sync Phase 5.14 統一ライブラリビュー

- **課題**:
    - pull 済みの曲だけが `library.json` に載るため、LibraryHost peer に存在する未取得曲がクライアントの一覧に見えなかった。
- **実装内容**:
    - `sync-remote-catalog` ストアを追加し、LibraryHost peer の `/sync/library/snapshot` metadata をキャッシュできるようにした。
    - `GetUnifiedLibrary()` を追加し、local 曲に `syncAvailability="local"`、remote 曲に `syncAvailability="remote"`、`syncSourceDeviceId`、`syncSourcePeerName`、`syncSourceTrackId` を付けて返すようにした。
    - local/remote および複数 peer の重複は `syncSongMatchKey` で dedup し、local 曲を優先するようにした。
    - renderer で remote 曲に `DL可能` バッジを表示し、アートワークはプレースホルダを使い、再生アクション対象外にした。
- **検証**:
    - `go test ./server -run 'TestGetUnifiedLibrary|TestRefreshSyncRemoteCatalog' -count=1`
    - `npm test --prefix src/renderer -- --run js/ui/sync-availability.test.ts`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-27a` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-30a` に更新。

### UX Sync Phase 5.13.1 再生回数ライブ通知

- **課題**:
    - `/sync/library/events` で peer から再生イベントを受信して `playcounts` を再計算しても、Wails UI へ `play-counts-updated` が emit されず、画面表示がライブ更新されなかった。
- **実装内容**:
    - `registerSyncRoutes` が `App` を保持し、同期イベントハンドラから `App.ctx` を参照できるようにした。
    - `/sync/library/events` の適用成功後に最新 `playcounts` を読み込み、`play-counts-updated` として frontend へ emit するようにした。
    - テスト容易性のため `playCountsEmitter` を差し替え可能にし、ctx なしの既存直呼び経路では nil-safe に何もしないようにした。
- **検証**:
    - `go test ./server -run 'TestSyncLibraryEventsEmitsUpdatedPlayCountsAfterApplyingEvents|TestSyncLibraryEventsRejectsInvalidMethod|TestSyncLibraryEventsPushStoresChildPlayEventsAndReturnsAcks' -count=1`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-26b` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-29b` に更新。

### UX Sync Phase 5.13 再生回数収束

- **課題**:
    - 同じ曲でも端末ごとに曲 ID が異なるため、sync 経由で pull していない曲同士の再生回数が同期されない。
    - `playcounts` と `sync-play-events` が二重ソースになり、再送・途中失敗・リセット時に恒久的なズレが残り得る。
- **実装内容**:
    - `syncSongMatchKey` を追加し、NFKC・小文字化・trim・空白圧縮・duration 秒丸めで正規化したメタデータキーを SHA-1 hex 化するようにした。
    - `uxsync.PlayEvent` に `matchKey` を追加し、ローカル再生イベントへ保存するようにした。
    - 受信イベントは `matchKey` 優先、旧イベントは `trackID` フォールバックでローカル path に解決するようにした。
    - 解決できないイベントはログには残し、`playcounts` へ幽霊エントリを作らないようにした。
    - `playcounts-base` と一度きり移行を追加し、表示用 `playcounts` を `base + logCount` の射影として再計算するようにした。
- **検証**:
    - `go test ./server -run 'TestSyncSongMatchKey|TestIncrementPlayCountRecordsLocalSyncPlayEvent|TestSyncLibraryEventsAppliesIncomingPlayCountsByMetadataWithoutPulledTrack|TestSyncLibraryEventsSkipsUnmatchedPlayCountsWithoutGhostEntry|TestIncrementPlayCountMigratesExistingCountsToBaseBeforeProjection|TestSyncPlayCountsConvergeAcrossBidirectionalMetadataMatchedEvents|TestSyncLibraryEventsFallsBackToTrackIDForLegacyEventsWithoutMatchKey|TestSyncLibraryEventsAppliesIncomingPlayCountsIdempotently' -count=1`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-26a` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-29a` に更新。

### UX Sync Phase 5.12 push転送メタデータ・ジャケット・再生回数

- **課題**:
    - FLAC を push 転送した際、音源本体だけが届き、表示メタデータ、ジャケット、再生回数が転送先に反映されないケースがあった。
- **実装内容**:
    - push 転送の multipart `metadata.track` に、既存ライブラリ上の表示メタデータを保持するテストを追加。
    - push 転送時、ローカル `playcounts` の対象曲エントリを `syncPlayCount` として metadata に同梱するようにした。
    - `/sync/library/import` 受信側で `syncPlayCount` を取り込み先パスの `playcounts` に反映し、`library.json` には転送用フィールドを残さないようにした。
    - 受信側で保存済み音源を再スキャンし、payload が薄い場合もタグ情報と埋め込みジャケットを補完できるようにした。
    - artwork part が届いた場合は `Artworks` と `Artworks/thumbnails` 配下へ保存し、`library.json` の `artwork.full` / `artwork.thumbnail` に反映する。
- **検証**:
    - `go test ./server -run 'TestPushSyncLibraryAssetsIncludesMetadataArtworkAndPlayCount|TestSyncLibraryImportAppliesUploadedArtworkAndPlayCount|TestPushSyncLibraryAssetsUploadsLocalTrackToRemotePeer|TestSyncLibraryImportRequiresTokenAndImportsUploadedTrack' -count=1`
    - `go test ./server -run 'TestSyncLibraryImportAppliesUploadedArtworkAndPlayCount|TestPushSyncLibraryAssetsIncludesMetadataArtworkAndPlayCount|TestSyncAssetArtworkServesArtworkByTrackID' -count=1`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-25b` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-28b` に更新。

### UX Sync Phase 5.11 自動音源差分同期と接続トースト

- **要望対応**:
    - Walkman 転送で使っている「未転送だけ扱う」考え方を UX Sync の自動同期にも寄せたい。
    - 接続できたため自動同期したことを右下トーストで分かるようにしたい。
- **実装内容**:
    - `AutoSyncPairedDevices()` が `LibraryHost` 役割を持つペア済み端末に対して `PullSyncLibraryAssets()` を実行し、未取得曲だけを自動取得するようにした。
    - 既に `syncSourceDeviceId` / `syncSourceTrackId` 付きで取り込み済みかつ実ファイルが存在する曲は skip とし、`pulledTracks` / `skippedTracks` として自動同期結果に集約する。
    - `LibraryHost` ではない peer からは音源本体を自動取得しない。
    - renderer が `ux-sync-auto-result` を購読し、接続できたため同期したこと、取得数、既存数、再生回数、ジャケット数を右下トーストに表示する。
- **検証**:
    - `go test ./server -run 'TestAutoSyncPairedDevicesPullsOnlyMissingTracksFromLibraryHost|TestAutoSyncPairedDevicesDoesNotPullTracksFromNonLibraryHost|TestAutoSyncPairedDevicesDownloadsMissingArtworkForImportedTrack|TestAutoSyncPairedDevicesPushesLocalPlayEventsToReachablePeer' -count=1`
    - `npm test --prefix src/renderer -- --run js/features/ux-sync-settings.test.ts`
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-24a` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-27a` に更新。

### UX Sync Crescent向けSSH自動同期CLI

- **課題**:
    - HariBote（Crescent）を検証用 Windows ノードとして使うため、GUI を起動せず SSH からペアリングと自動同期ワンショットを実行したい。
    - 既存 CLI は初期化と音源 pull のみで、ペアリング後に既知 peer の到達URLを確実に残す導線が不足していた。
- **対応**:
    - `server/app_sync_cli_test.go`:
      - `--sync-pair <baseURL>` が6桁コード確認フローを通して同期トークンと既知 peer を保存するテストを追加。
      - `--sync-auto-once` が保存済みペア端末へ `AutoSyncPairedDevices()` を一回実行するテストを追加。
    - `server/app_sync_cli.go`:
      - SSH 検証向けに `--sync-pair` と `--sync-auto-once` を追加。
    - `server/app_sync.go`:
      - ペアリング確定時に、リモート端末の `baseURL` / 表示名 / 役割を既知 peer として保存するように変更。
- **検証**:
    - `go test ./server -run 'TestRunSyncCLI|TestConfirmSyncPairingStoresRemoteIssuedTokenForRemoteDevice' -count=1`
    - `go test ./server -run 'Test.*Sync.*' -count=1`
    - Crescent (`HariBote@192.168.0.120`) に Go / MSYS2 / Wails CLI を構築し、`wails build -clean -nopackage` で `C:\Users\HariBote\UX-Music-sync-test\UX-Music\build\bin\UX-Music.exe` を作成。
    - Crescent で `libportaudio.dll` を `build\bin` に同梱し、PATH なしで CLI が起動できることを確認。
    - Crescent から `http://192.168.0.226:8765` の Mac mini へ `--sync-reset-test-data`、`--sync-pair`、`--sync-auto-once` を実行し、`checkedDevices=1` / `syncedDevices=1` を確認。
    - Crescent から `--sync-pull-one` で Mac mini の音源を1曲取得し、その後 `--sync-auto-once` で `syncedArtwork=1` を確認。
- **バージョン情報の更新**:
    - `src/renderer/package.json` と `src/renderer/package-lock.json` を `1.0.0-Beta-23a` に更新。
    - `markdown/requirement.md` を `0.1.9-Beta-26a` に更新。

### UX Sync Phase 5.9 空き容量安全停止

- **要望対応**:
    - システムに数GBの空きが無ければ同期を停止するオプションを追加した。
- **実装内容**:
    - `settings.syncMinFreeSpaceGB` を追加し、`0` または未設定なら無効、正の値なら GB 単位の最低空き容量として扱う。
    - `AutoSyncPairedDevices()` は同期開始前に `config.GetUserDataPath()` のあるボリュームの空き容量を確認し、閾値未満なら peer へ接続せず `paused` 状態で停止する。
    - `PullSyncLibraryAssets()` と `/sync/library/import` も同じ空き容量安全停止を通し、受信側ストレージを増やす同期操作を止められるようにした。
    - UX Sync 専用設定画面の `保存` タブを有効化し、最低空き容量を GB 単位で保存できる UI を追加した。
- **検証**:
    - `go test ./server -run 'TestAutoSyncPairedDevicesStopsWhenFreeSpaceIsBelowSafetyLimit|TestAutoSyncPairedDevicesPushesLocalPlayEventsToReachablePeer' -count=1`
    - `npm test -- --run js/features/ux-sync-settings.test.ts`
- **仕様同期**:
    - `library.storage-safety.v1` capability を追加。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-25a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-22a` に更新。

### UX Sync Phase 5.8 ジャケットの自動補完同期

- **要望対応**:
    - 接続できたら手動操作なしで同期される対象に、再生回数だけでなくジャケット画像も含めたい要望に対応した。
- **実装内容**:
    - `/sync/assets/{trackId}/artwork` を追加し、同期トークン付きでライブラリ登録済み曲の保存済みジャケットを取得できるようにした。
    - `/sync/library/snapshot` は巨大な `artwork` blob を直接載せず、`syncArtwork` 参照だけを返すようにした。
    - multipart import / push で任意の `artwork` part を扱い、受信側の `Artworks` 配下へ保存して `library.json` の `artwork.full` に反映できるようにした。
    - `AutoSyncPairedDevices()` がペア済み端末へ接続できた時、既に取り込み済みの同期曲でジャケットが欠けているものを自動補完するようにした。
- **検証**:
    - `go test ./server -run 'TestAutoSyncPairedDevicesDownloadsMissingArtworkForImportedTrack|TestSyncAssetArtworkServesArtworkByTrackID' -count=1`
- **仕様同期**:
    - `library.artwork.v1` capability を追加。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-24a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-21a` に更新。

### UX Sync Phase 5.7 再生回数の自動同期

- **要望対応**:
    - 手動で push するのではなく、接続できたら同期される形へ寄せるため、まず再生回数イベントを自動同期する基盤を追加した。
- **実装内容**:
    - `IncrementPlayCount` が既存 `playcounts` 更新に加えて、ローカル端末の `sync-play-events` へ `PlayEvent` を記録するようにした。
    - `syncSourceTrackId` を持つ子側取り込み曲では、親側の曲IDを `PlayEvent.trackId` に使い、親へ戻した時に同じ曲として集計できるようにした。
    - `/sync/library/events` で受信した新規イベントを `playcounts` へ冪等に反映し、同じ `eventId` の再送では二重加算しないようにした。
    - `AutoSyncPairedDevices()` を追加し、保存済みペア端末の到達URLへローカル再生イベントを同期トークン付きでpushできるようにした。
    - アプリ起動後は軽量な自動同期ループで、到達可能なペア済み端末へ再生イベント同期を定期的に試行する。
- **検証**:
    - `go test ./server -run 'TestIncrementPlayCountRecordsLocalSyncPlayEvent|TestSyncLibraryEventsAppliesIncomingPlayCountsIdempotently|TestAutoSyncPairedDevicesPushesLocalPlayEventsToReachablePeer' -count=1`
- **仕様同期**:
    - `library.auto-sync.v1` capability を追加。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-23a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-20a` に更新。

### UX Sync Phase 5.6.1 MP3転送のストリーミング化

- **要望対応**:
    - MP3 320kbps 転送が「1曲丸ごと変換してから送る」ため遅く感じる問題に対応した。
- **実装内容**:
    - MP3 320kbps 転送時に一時MP3ファイルを作り切る処理を廃止し、`ffmpeg -f mp3 pipe:1` の stdout を multipart upload の file part へ直接流すようにした。
    - `prepareSyncTrackForTransfer` を転送用 `io.ReadCloser` を返す構造に変更し、原本転送はローカルファイル reader、MP3転送は ffmpeg stdout reader を使うようにした。
    - ffmpeg の終了待ちと reader close を一度だけ行う cleanup を追加し、変換失敗は該当曲の failed として扱うようにした。
- **検証**:
    - `go test ./server -run 'TestPushSyncLibraryAssetsWithOptionsTranscodesLosslessToMP3320|TestPushSyncLibraryAssetsWithOptionsStreamsMP3EncodingIntoUpload|TestPushSyncLibraryAssetsEmitsTransferProgressWithFileAndSpeed' -count=1`
- **仕様同期**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-22b` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-19b` に更新。

### UX Sync Phase 5.6 転送進捗表示とMP3 320kbps転送

- **要望対応**:
    - 音源転送中に、現在送っているファイル名と転送速度が分かるようにした。
    - FLAC など重いロスレス音源を、送信時に MP3 320kbps へ変換してから転送できるようにした。
- **実装内容**:
    - `ux-sync-transfer-progress` Wails event を追加し、push / pull の転送中に `direction`、`stage`、`fileName`、件数、byte数、`bytesPerSecond`、`encodingMode` をUIへ通知するようにした。
    - `PushSyncLibraryAssetsWithOptions(baseURL, limit, options)` を追加し、既存 `PushSyncLibraryAssets(baseURL, limit)` は原本転送の互換APIとして維持した。
    - `encodingMode: "mp3_320"` 指定時、MP3以外の音源を `ffmpeg` / `libmp3lame` / `320k` で一時変換し、multipart import には `.mp3` と `syncTransferEncoding: "mp3_320"` を付けて送るようにした。
    - UX Sync 設定画面の同期タブに転送音質セレクトを追加し、転送中はファイル名、件数、転送速度、転送量を表示するようにした。
    - protocol capability に `library.transfer-progress.v1` と `library.transcode.mp3-320.v1` を追加した。
- **検証**:
    - `go test ./server -run 'TestPushSyncLibraryAssetsWithOptionsTranscodesLosslessToMP3320|TestPushSyncLibraryAssetsEmitsTransferProgressWithFileAndSpeed' -count=1`
    - `npm test -- --run js/features/ux-sync-settings.test.ts`
- **仕様同期**:
    - `markdown/ux-music-sync-protocol.md`、`markdown/ux-music-sync-plan.md`、`markdown/requirement.md`、`markdown/features.md`、`markdown/roadmap.md`、`markdown/Task.md` を更新。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-22a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-19a` に更新。

### UX Sync Phase 5.5 プロトコルスキーマとバージョンネゴシエーション

- **要望対応**:
    - UX Sync のプロトコルを将来のバージョン違いに強くするため、スキーマ定義と capability / version negotiation を追加した。
- **実装内容**:
    - UX Sync protocol 定数として `ux-music-sync` / `0.2` / `2026-06-09` / capability 一覧を追加した。
    - `/sync/identity` が `protocolVersion`、`minCompatibleProtocolVersion`、`schemaVersion`、`capabilities`、`negotiation` を返すようにした。
    - `fetchSyncIdentity` が自分の protocol/schema/capabilities をヘッダで申告し、非互換 major の peer を同期操作前に拒否するようにした。
    - `/sync/schema` を追加し、endpoint / message / capability / 拡張規則を含む機械可読スキーマを返すようにした。
    - mDNS TXT に `schemaVersion` と `capabilities` を追加した。
    - `markdown/ux-music-sync-protocol.md` を追加し、未知フィールド・未知 capability・`extensions` の扱いを含む将来互換方針を明文化した。
    - Windows ビルドで macOS 向け MTP 実装と Windows stub が衝突しないよう、MTP 実装に build tag を追加し Windows stub を整理した。
- **検証**:
    - `go test ./server -run 'TestSyncIdentityIncludesSchema|TestFetchSyncIdentitySendsProtocol|TestFetchSyncIdentityRejectsIncompatibleProtocolMajor|TestSyncSchemaEndpoint|TestSyncMDNSAdvertiseInfo' -count=1`
    - `go test ./internal/uxsync -count=1`
- **仕様同期**:
    - `markdown/Task.md`、`markdown/requirement.md`、`markdown/features.md`、`markdown/roadmap.md`、`markdown/ux-music-sync-plan.md` を更新。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-21b` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-18b` に更新。
- **判断**:
    - 多少のバージョン差は unknown field / capability を無視して進め、major 不一致は同期操作前に止める方針を実装した。
    - 今後 token と `sourceDeviceId` の対応検証を強める場合は、新しい capability と schema version で段階導入する。

### UX Sync Phase 5.4 音源push転送

- **要望対応**:
    - UX Sync で相手から取得するだけでなく、こちらから相手へ音源を転送できるようにした。
- **実装内容**:
    - `/sync/library/import` を追加し、同期トークン認証済みの multipart アップロードを `SyncLibrary` へ取り込めるようにした。
    - 受信側はアップロードされたメタデータから `syncSourceDeviceId` / `syncSourceTrackId` を保存し、同じ同期元・同じ曲の重複転送を skip するようにした。
    - `PushSyncLibraryAssets(baseURL, limit)` を追加し、保存済み同期トークンでローカルライブラリの音源をペア済み端末へ転送できるようにした。
    - UX Sync 専用設定画面の `同期` タブに `1曲転送` / `全曲転送` を追加し、転送結果を転送数・既存数・失敗数と受信側保存先として表示するようにした。
    - renderer と Wails binding に `PushSyncLibraryAssets` を追加した。
- **検証**:
    - `go test ./server -run 'TestSyncLibraryImport|TestPushSyncLibraryAssets' -count=1`
    - `npm test -- --run js/features/ux-sync-settings.test.ts`
    - `npm run typecheck`
- **仕様同期**:
    - `markdown/Task.md`、`markdown/requirement.md`、`markdown/features.md`、`markdown/roadmap.md`、`markdown/ux-music-sync-plan.md` を更新。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-20a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-17a` に更新。
- **判断**:
    - Mac mini 側から Windows 側へ能動的に音源を送り込めるため、発見・ペアリング後の同期操作が pull / push の両方向に揃った。

### UX Sync Phase 5.3.1 ペア済み端末復元と同期操作修正

- **要望対応**:
    - UX Sync 専用設定画面を閉じるとペアリング済み表示が消え、同期ボタンも使えない状態を修正した。
- **実装内容**:
    - `ListSyncDevices()` を追加し、保存済み `syncAuthTokens` と `syncKnownPeers` から同期トークンを返さずペア済み端末一覧を取得できるようにした。
    - UX Sync 専用設定画面で mDNS discovery 結果とペア済み端末一覧をマージし、画面を閉じた後もペアリング済み状態と同期元候補を復元するようにした。
    - ペアリング確定後に端末一覧と同期元セレクトを更新し、到達URLを持つペア済み端末では `1曲取得` / `全曲取得` を押せるようにした。
    - ペア済み peer は `ペアリング済み` と表示し、再ペアリング用の接続ボタンを `接続済み` として無効化するようにした。
    - renderer と Wails binding に `ListSyncDevices` を追加した。
- **検証**:
    - `go test ./server -run 'TestListSyncDevices' -count=1`
    - `npm test -- --run js/features/ux-sync-settings.test.ts`
    - `npm run typecheck`
- **仕様同期**:
    - `markdown/Task.md`、`markdown/requirement.md`、`markdown/features.md`、`markdown/roadmap.md`、`markdown/ux-music-sync-plan.md` を更新。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-19b` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-16b` に更新。
- **判断**:
    - ペアリング情報が一時的なUI状態だけに閉じていた問題を解消し、たまに接続される端末でも保存済みペア情報から同期操作へ戻れる状態になった。

## 2026年6月8日

### UX Sync Phase 5.3 音源pull GUI

- **要望対応**:
    - SSH CLI で通した Mac mini からの音源pullを、UX Sync 専用設定画面から扱えるようにした。
- **実装内容**:
    - UX Sync 専用設定画面の `同期` タブを有効化した。
    - 発見済み / 既知 peer の到達URLを同期元セレクトへ反映するようにした。
    - `1曲取得` ボタンから `PullSyncLibraryAssets(baseURL, 1)`、`全曲取得` ボタンから `PullSyncLibraryAssets(baseURL, 0)` を呼ぶようにした。
    - 音源pull結果を `downloaded` / `skipped` / `failed` と保存先パスとして表示するようにした。
    - `PullSyncLibraryAssets` binding が無い環境、または同期元未選択時は取得ボタンを無効化するようにした。
    - renderer に `normaliseSyncPullResult`、`syncPullActionState`、`formatSyncPullResultSummary` のテストを追加した。
- **検証**:
    - `npm test -- --run js/features/ux-sync-settings.test.ts`
    - `npm run typecheck`
- **仕様同期**:
    - `markdown/Task.md`、`markdown/requirement.md`、`markdown/features.md`、`markdown/roadmap.md`、`markdown/ux-music-sync-plan.md` を更新。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-19a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-16a` に更新。
- **判断**:
    - SSH CLI で通した親から子への音源pullを、UX Sync 専用設定画面から操作できる第一段階に到達した。
    - destructive な検証用初期化は誤操作リスクが高いため、GUI には出さず CLI 専用に残した。

### UX Sync Phase 5.2 音源pullとSSH検証CLI

- **要望対応**:
    - Windows 側をテスト専用ノードとして使いやすくし、SSH から初期化と音源pullを行えるようにした。
- **実装内容**:
    - GUI / WebView2 を起動しない `--sync-reset-test-data`、`--sync-pull-one`、`--sync-pull` の CLI 入口を追加した。
    - `/sync/library/snapshot` を追加し、同期トークン認証済み端末へアートワーク blob を除いた曲一覧を返すようにした。
    - `/sync/assets/{trackId}/file` を追加し、同期トークン認証済み端末へ登録済み曲IDの原本ファイルを返すようにした。
    - `PullSyncLibraryAssets(baseURL, limit)` を追加し、保存済み `syncAuthTokens` を使って親から曲一覧と音源を取得し、子側 `SyncLibrary` 配下へ保存して `library.json` へ取り込むようにした。
    - 取り込んだ曲には `syncSourceDeviceId` / `syncSourceTrackId` / `syncImportedAt` を付与し、同じ親・同じ曲の再取り込みを避けるようにした。
    - `ResetSyncTestData` は `syncDeviceId` / `syncAuthTokens` / `syncKnownPeers` を温存し、検証用ライブラリ・再生回数・解析・同期イベント・アートワーク・キャッシュ・プレイリストを初期化し、`libraryPath` を `SyncLibrary` へ向け直す。
    - Wails binding と renderer bridge に `PullSyncLibraryAssets(baseURL, limit)` を追加した。
- **検証**:
    - `go test ./server -run 'TestSyncLibrarySnapshot|TestSyncAssetFile|TestPullSyncLibraryAssets|TestResetSyncTestData' -count=1`
    - Mac 側 `go test ./...`
    - Mac 側 `npm test -- --run js/features/ux-sync-settings.test.ts`
    - Mac 側 `npm run typecheck`
    - Mac 側 `wails build -clean -nopackage`
    - Mac 側で新ビルドを `open /Users/yuki/GitHub/UX-Music/build/bin/UX-Music` から起動し、`/sync/identity` が `YukinoMac-mini` を返すことを確認。
    - Mac 側 `/sync/library/snapshot` が Windows 側保存済み同期トークンで `200` を返し、812曲のスナップショットを返すことを確認。
    - Windows 側 `go test ./server -run TestSyncLibrarySnapshot^|TestSyncAssetFile^|TestPullSyncLibraryAssets^|TestResetSyncTestData -count=1`
    - Windows 側 `npm run typecheck`
    - Windows 側 `wails build -clean -nopackage`
    - Windows 側 `C:\Users\gzabu\UX-Music-sync-test\build\bin\UX-Music.exe --sync-reset-test-data`
    - Windows 側 `C:\Users\gzabu\UX-Music-sync-test\build\bin\UX-Music.exe --sync-pull-one http://192.168.0.226:8765`
    - Windows 側 `SyncLibrary` に Mac mini 由来の FLAC 2曲が保存され、`library.json` の `syncSourceDeviceId` / `syncSourceTrackId` とファイルサイズを確認。
- **仕様同期**:
    - `markdown/Task.md`、`markdown/requirement.md`、`markdown/features.md`、`markdown/roadmap.md`、`markdown/ux-music-sync-plan.md` を更新。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-18a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-15a` に更新。
- **判断**:
    - 圧縮アセット生成は未実装だが、親 Mac mini の既存原本を子 Windows の管理ライブラリへ pull する縦串は、ローカルテストと `mainpc` への実通信検証の両方で通った。
    - `--sync-pull-one` は既存取り込み済み曲を skip し、次の未取得曲を1曲 download する挙動として動作した。

### UX Sync Phase 5.1 Windows側発見fallback

- **要望対応**:
    - Mac 側から Windows peer は見えるが、Windows 側の mDNS discovery が空になって Mac mini を見つけられない非対称状態を調査した。
- **実装内容**:
    - `mainPC` から `http://192.168.0.226:8765/sync/identity` が応答することを確認し、HTTP 到達性ではなく discovery の問題だと切り分けた。
    - mDNS 広告に使う表示名から `.local` suffix を除去し、`YukinoMac-mini.local` ではなく `YukinoMac-mini` として広告するようにした。
    - inbound pairing confirm 成功時に、相手 `deviceId`、表示名、実通信元 IP から既知 peer を `settings.syncKnownPeers` へ保存するようにした。
    - `DiscoverSyncDevices(timeoutMs)` と `/sync/discover` が mDNS 結果と既知 peer をマージするようにした。
    - mainpc 側のビルド環境に `gcc` / `pkg-config` / portaudio header と `.pc` を用意し、Windows バイナリを再ビルドできる状態にした。
    - 既に古いバイナリでペアリング済みだった Windows 設定へ、Mac mini の `syncKnownPeers` を一度だけ補完した。
- **検証**:
    - Mac 側 `dns-sd -B _uxmusic-sync._tcp local` で `YukinoMac-mini` が複数 interface に広告されることを確認。
    - `mainPC` から `http://192.168.0.226:8765/sync/identity` が応答することを確認。
    - Windows 側 `npm test -- --run js/features/ux-sync-settings.test.ts`
    - Windows 側 `npm run typecheck`
    - Windows 側 `go test ./server -run "TestSyncPairingConfirmStoresKnownPeer|TestMergeSyncKnownPeers|TestSyncMDNSAdvertiseInfo|TestNormaliseSyncDisplayName" -count=1`
    - Windows 側 `wails build -clean -nopackage`
    - Windows 側 `settings.json` に `syncKnownPeers` として `YukinoMac-mini` / `http://192.168.0.226:8765` が保存されたことを確認。
    - Mac 側 `go test ./...`
    - Mac 側 `npm test -- --run js/features/ux-sync-settings.test.ts`
    - Mac 側 `npm run typecheck`
- **判断**:
    - Windows の mDNS browse 自体は SSH 上の Go smoke で空のままだが、ペアリング済み端末は既知 peer fallback で発見一覧へ補完できる構造になった。
    - SSH 経由で Windows GUI を起動すると WebView2 が `Invalid window handle` で落ちるため、更新済み `C:\Users\gzabu\UX-Music-sync-test\build\bin\UX-Music.exe` は Windows のデスクトップ側から起動して確認する。

### UX Sync Phase 5 専用設定画面

- **要望対応**:
    - Sync を通常設定の一項目ではなく、専用の設定画面として扱えるようにした。
- **実装内容**:
    - 通常設定モーダルに混在していた UX Sync の探索・ペアリング UI を、UX Sync 専用設定画面へ切り出した。
    - 通常設定には `UX Sync設定を開く` の入口だけを表示するようにした。
    - Wails sync binding が無い renderer 単体環境では UX Sync 入口を非表示にする状態判定を追加した。
    - UX Sync 専用設定画面の `端末` タブに探索ボタン、探索状態、peer 一覧、6桁コード確認ペアリング導線を集約した。
    - 後続の同期状態・保存ポリシー設定を載せるため、`同期` と `保存` のタブ枠を追加した。
- **検証**:
    - `npm test -- --run js/features/ux-sync-settings.test.ts`
    - `npm run typecheck`
- **仕様同期**:
    - `markdown/Task.md`、`markdown/requirement.md`、`markdown/features.md`、`markdown/roadmap.md`、`markdown/ux-music-sync-plan.md` を更新。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-17a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-14a` に更新。
- **判断**:
    - UX Sync は通常設定の一項目ではなく、専用画面で端末・同期・保存を管理していく形へ移行した。

### UX Sync Phase 4 ペアリングUI

- **要望対応**:
    - UI上で発見できた Windows 側 peer に対して、設定画面からそのままペアリング開始・確定できる導線を追加した。
- **実装内容**:
    - Wails 向けに `StartSyncPairing(baseURL)` と `ConfirmSyncPairing(baseURL, sessionID, code, expectedRemoteDeviceID)` を追加。
    - `StartSyncPairing` はリモート `/sync/identity` で端末情報を取得し、ローカル `deviceId` を使って `/sync/pairing/start` を呼ぶ。
    - `ConfirmSyncPairing` はリモート `/sync/pairing/confirm` が返したトークンを、リモート `deviceId` 宛の同期トークンとしてローカル設定へ保存する。
    - ペアリング開始時の `remoteDeviceId` と確定時に再取得した `deviceId` が異なる場合は、トークンを保存せず失敗させる。
    - 設定画面の UX Sync peer カードに「接続」ボタンを追加し、6桁コード表示、確定、キャンセル、ペアリング済み表示まで進めるようにした。
    - `reachableBaseUrl` を優先し、未取得時は `host` / `hosts` と `port` からペアリング用 URL を構成する renderer ロジックを追加。
- **検証**:
    - `go test ./server -run 'TestStartSyncPairing|TestConfirmSyncPairing|TestSyncPairing' -count=1`
    - `npm test -- --run js/features/ux-sync-settings.test.ts`
    - `npm run typecheck`
- **仕様同期**:
    - `markdown/Task.md`、`markdown/requirement.md`、`markdown/features.md`、`markdown/roadmap.md`、`markdown/ux-music-sync-plan.md` を更新。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-16a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-13a` に更新。
- **残課題**:
    - ペア済み端末一覧と解除 UI は未実装。
    - 現状の6桁コードはリモート API 応答として開始側に返るため、Bluetooth 数値確認のように双方が独立表示する方式への強化は後続で扱う。

### UX Sync Phase 3.1 macOS mDNS fallback

- **要望対応**:
    - VLAN / 複数 NIC 環境で、OS の Bonjour では Windows 側 `mainPC` が見えるのにアプリ側 discovery が `mainPC` を取りこぼす状態を半自動テストで再現した。
- **実装内容**:
    - macOS では `zeroconf` discovery と OS 標準の `dns-sd -B/-L` の結果をマージするようにした。
    - `dns-sd` 出力を `MDNSPeer` へ正規化し、既存の `ResolveReachablePeers` で `reachableBaseUrl` を選べるようにした。
    - `markdown/Task.md` と `markdown/requirement.md` を macOS mDNS fallback の実装内容へ同期。
- **検証**:
    - `dns-sd -B _uxmusic-sync._tcp local` で `mainPC` を確認。
    - `dns-sd -L mainPC _uxmusic-sync._tcp local` で `mainPC.local.:8765` と TXT レコードを確認。
    - 半自動 Go smoke で `DiscoverMDNS` → `ResolveReachablePeers` が Mac 自身と `mainPC` / `reachableBaseUrl=http://mainPC.local:8765` を返すことを確認。
    - `go test ./internal/uxsync`
    - `go test ./...`
- **仕様同期**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-15b` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-12b` に更新。
- **判断**:
    - UI 側が `DiscoverSyncDevices(timeoutMs)` を呼べば、今回の fallback を通って Windows 側 `mainPC` を検出できる状態になった。

### UX Sync Phase 3 自動発見UI

- **要望対応**:
    - 設定画面から LAN 内の UX Music 端末を探索し、外出先や renderer 単体開発環境でも通常 UI を壊さず確認できるようにした。
- **実装内容**:
    - renderer に `ux-sync-settings` の peer 正規化・接続候補表示ロジックを追加。
    - 設定画面に UX Sync セクションと「同期端末を探す」ボタンを追加。
    - Wails の `DiscoverSyncDevices(timeoutMs)` から得た `reachableBaseUrl`、役割、複数 NIC の候補 `hosts` を一覧表示するようにした。
    - Wails binding が無い renderer 単体開発環境では UX Sync セクションを非表示にし、通常の設定画面を壊さないようにした。
    - `markdown/Task.md`、`markdown/requirement.md`、`markdown/features.md`、`markdown/roadmap.md`、`markdown/ux-music-sync-plan.md` を UX Sync 自動発見 UI の実装内容へ同期。
- **検証**:
    - `npm test -- --run js/features/ux-sync-settings.test.ts`
    - `npm test -- --run`
    - `npm run typecheck`
    - `go test ./...`
    - `git diff --check`
- **仕様同期**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-15a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-12a` に更新。
- **判断**:
    - UI 側の自動発見一覧表示は実装済み。
    - 発見 peer から6桁コード確認ペアリングへ進む導線と、ペア済み端末管理 UI は後続フェーズに残す。

### UX Sync Phase 2 mDNS 自動発見基盤

- **要望対応**:
    - 同一 LAN 上の UX Music 端末を、手入力ではなく mDNS / Bonjour で自動発見できるようにした。
- **実装内容**:
    - `internal/uxsync` に mDNS サービス定義、TXT レコード生成、発見 peer 正規化、複数アドレス保持を追加。
    - `github.com/grandcat/zeroconf` を導入し、`_uxmusic-sync._tcp.local.` の広告と探索を実装。
    - LAN HTTP サーバー起動時に UX Sync mDNS 広告を開始し、停止時に shutdown するようにした。
    - Wails 向けに `DiscoverSyncDevices(timeoutMs)` を追加。
    - `/sync/identity` に `deviceId` / `displayName` / `roles` を含めるよう更新。
    - 複数NIC環境で同じ `deviceId` が複数アドレスを返す場合、`hosts` に全候補を保持するようにした。
    - `hosts` 候補へ `/sync/identity` を順番に probe し、到達可能な `reachableBaseUrl` を自動選択するようにした。
    - 末端側が IP 手入力や OS の `dns-sd` 操作をしなくても、アプリ側の mDNS 探索と自動 probe で接続候補を得られる方針にした。
- **検証**:
    - `go test ./internal/uxsync`
    - `go test ./internal/uxsync ./server`
    - 検証用サーバーを `0.0.0.0:9876` で起動し、macOS `dns-sd -B _uxmusic-sync._tcp local` で `UX Music mDNS Test` の広告を確認。
    - Go の `uxsync.DiscoverMDNS` で広告を発見し、`hosts` に `192.168.1.182`、`192.168.0.226`、`192.168.1.48`、Tailscale / IPv6 候補が含まれることを確認。
    - Go の `ResolveReachablePeers` で `reachableBaseUrl` が自動設定されることを確認。
    - SSH 接続した `mainpc` から `http://192.168.0.226:9876/sync/identity` が応答することを確認。
    - `mainpc` には `dns-sd` が無かったため、Windows 側での mDNS browse は未実施。
- **仕様同期とバージョン更新**:
    - `markdown/Task.md`、`markdown/requirement.md`、`markdown/features.md`、`markdown/roadmap.md`、`markdown/ux-music-sync-plan.md` を更新。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-14b` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-11b` に更新。
- **残課題**:
    - UI 上の自動発見一覧表示と、発見 peer からペアリングへ進む導線は後続フェーズに残す。

### UX Sync Phase 1 ペアリングと再生イベントプッシュ基盤

- **要望対応**:
    - Mac mini を親、mainpc / 持ち運び端末を子とする同期に向けて、6桁コード確認ペアリングと、子側で加算された再生カウントを親へプッシュする基盤を実装した。
    - たまにしか接続されない端末でも、同じ再生イベントを再送して安全に同期できるようにした。
- **実装内容**:
    - `internal/uxsync` を追加し、`PlayEvent` の重複排除、同時再生の別イベント採用、再生回数集計、アウトボックス ACK pruning、6桁ペアリングコード生成を実装。
    - `/sync/identity`、`/sync/pairing/start`、`/sync/pairing/confirm`、`/sync/library/events` を既存 LAN HTTP サーバーへ追加。
    - Wear 認証と Sync 認証を `lanAuthMiddleware` で分離。
    - Sync 認証は `X-UX-Music-Sync-Token` / Bearer / `syncToken` を受け付ける。
    - `sync-play-events` をイベントログとして保存し、同じ `eventId` の再送で再生回数が二重加算されないようにした。
    - `Store.Save` がユーザーデータディレクトリを自動作成するようにした。
- **検証**:
    - `go test ./internal/uxsync`
    - `go test ./server -run 'TestSyncPairing|TestSyncAuth|TestLanAuth|TestSyncLibraryEvents' -count=1`
    - `go test ./internal/store ./server ./internal/uxsync`
    - `go test ./...`
    - SSH 接続した `mainpc` から `192.168.0.226:9876` の検証用サーバーへ、ペアリング開始、6桁コード confirm、認証付き `/sync/library/events` push、同一イベント再送を実行。
    - 実通信検証では `firstAccepted=1`、`secondAccepted=1`、`ackSequence=1` を確認し、保存された `sync-play-events` は `evt_mainpc_0001` 1件のみであることを確認。
- **仕様同期とバージョン更新**:
    - `markdown/Task.md`、`markdown/requirement.md`、`markdown/features.md`、`markdown/roadmap.md`、`markdown/ux-music-sync-plan.md` を更新。
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-13a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-10a` に更新。
- **残課題**:
    - `mainpc` から `192.168.1.182` へは到達できなかったが、`192.168.0.226` では到達できた。複数NIC環境で `GetWearServerAddress()` が最適なLANアドレスを選ぶ改善が必要。
    - mDNS / Bonjour、自動発見、UI、圧縮アセット、WebSocket 再生移行は後続フェーズに残す。

### UX Music Sync 実装計画を文書化

- **要望対応**:
    - 同一 LAN 上で、6桁コード確認ペアリング、母艦 Mac mini と持ち運び MacBook Air の役割分担、音源・再生履歴・再生状態の同期を実装するための計画をまとめた。
- **作成内容**:
    - `markdown/ux-music-sync-plan.md` を追加。
    - `Library Host` / `Portable Client` / `Playback Target` / `Controller` の役割モデルを定義。
    - mDNS / Bonjour による発見、6桁コード確認、長期端末鍵保存、認証済み HTTP / WebSocket 通信の流れを整理。
    - 再生回数を数値同期ではなく `Play Event` のマージで扱う方針を明記。
    - `Portable Client` の再生カウントを `Library Host` へプッシュするアウトボックス、親側取り込み確認、たまに接続される端末向けの再送設計を追記。
    - Mac mini と MacBook Air で同じ曲を同時に再生した場合は別イベントとして両方を採用し、同じイベントの再送だけを重複排除する方針を明記。
    - ロスレス原本は `Library Host` に置き、`Portable Client` は圧縮アセットと選択キャッシュを持つ設計を明記。
    - 再生移行、キャッシュ方針、競合解決、フェーズ別テスト観点、MVP完了条件を整理。
- **仕様同期**:
    - `markdown/roadmap.md`、`markdown/features.md`、`markdown/requirement.md` に UX Sync 計画への参照を追加。
- **判断**:
    - 今回はドキュメント作成のみのため、実装コードとテストは追加していない。
    - 実装に入る際は、フェーズごとに `markdown/Task.md` を更新し、テストを先に追加する。

### TXT専用歌詞同期の音源候補選択と実ライブラリ検証

- **要望対応**:
    - 同期済みLRCを実装入力に使わず、時刻なしTXT歌詞だけがある曲をローカルで同期しやすくしたい。
    - バックエンドAPI課金を避け、Macローカルでfull音源・ボーカル分離・`speech align` を含めて試行したい。
- **実装内容**:
    - Python fallback に `UX_MUSIC_LYRICS_SYNC_AUDIO_SOURCES=full|vocals|both` を追加。
    - `full` ではDemucsを通らず元音源を直接 faster-whisper へ渡す。
    - `both` では元音源候補とボーカル候補をそれぞれTXT行へ整列し、参照LRCを使わない品質スコアで候補を選択する。
    - 候補結果に `audioSource` / `alignmentQualityScore` / `candidateScores` を追加し、検証時にどの経路が選ばれたか追跡可能にした。
- **検証**:
    - `python/.venv/bin/python -m pytest python/tests -m 'not heavy' -q` → `30 passed, 1 deselected`
    - `/Users/yuki/doc/uxmusic` 5曲ベンチ（LRCから時刻を捨てたTXT相当入力、LRC時刻は答え合わせのみ、`base` / `full`）:
        - アムネシア: `MAE(after_tol)=0.734s`、0.8秒級に到達。
        - PROMINENCE: `81.670s`、反復ブロックとASR欠落で未達。
        - Lone Wolf: `58.186s`、未達。
        - main heroine: `93.846s`、未達。
        - Twilight: `28.689s`、未達。
    - PROMINENCE / `vocals` / `base`: `auto=23.731s`, `ja=69.775s`, `auto-ja=28.219s`。fullより改善するが0.8秒級には未達。
    - `speech align` は `/opt/homebrew/bin/speech` を検出し、アムネシアのボーカル抽出音声で実行できたが、簡易行復元では `MAE(after_tol)=3.395s` で採用見送り。
- **判断**:
    - TXTだけの実運用制約では、既存LRCを参照する経路は使わず、参照LRCはベンチ専用に限定。
    - アムネシアはfull音源ASRで0.8秒級に届くが、5曲全体では安定しない。
    - PROMINENCE系の破綻は、曲全体一括ASRセグメントからの後段整列では限界があり、セクション分割・複数候補DP・歌詞反復ブロックの構造推定が次の本命。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-12c` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-9c` に更新。

### Python fallback Stage3の未来ドリフト修復と0.8秒級同期検証

- **要望対応**:
    - ローカル完結のまま、`IGNORE/` セットで0.8秒級まで自動歌詞同期誤差を減らせるか試行。
- **実装内容**:
    - `stage3_align` に、後半の繰り返しフレーズへ大きく吸われた行を、飛ばされたASRセグメントへ戻す未来ドリフト修復を追加。
    - 繰り返しブロック末尾の延長補正を、未来ドリフト修復と単調化の後にも再適用。
    - `UX_MUSIC_SYNC_FORWARD_DRIFT_GAP_SECONDS`（既定 `75.0`）と `UX_MUSIC_SYNC_FORWARD_DRIFT_MAX_ROWS`（既定 `32`）を追加。
- **検証**:
    - `cd python && .venv/bin/python -m pytest tests/ -m 'not heavy' -v`
    - アムネシア / `medium` は同一ASR結果への後段補正で `MAE(after_tol)=0.737s` まで到達したが、実パイプライン再推論では `2.564s`。
    - PROMINENCE / `base` は `123s`級の全体ドリフトから `20.562s` まで改善。
    - Lone_Wolf / `base` は `109s`級の全体ドリフトから `24.243s` まで改善。
- **判断**:
    - 0.8秒級を安定達成するには、曲全体一括整列ではなく、チャンク化・複数候補保持・VAD/ASRアンカーによるセクション単位アラインメントが必要。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-12b` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-9b` に更新。

### macOSローカル強制アラインメント経路を追加

- **要望対応**:
    - バックエンドAPI課金を避け、Mac上で完結する自動歌詞同期を優先したい。
    - 素の Whisper の word timestamp より、既存歌詞を音声に直接合わせる強制アラインメントを使いたい。
- **実装内容**:
    - Swift sidecar に `Qwen3 Forced Aligner` / `speech align` 互換 CLI を優先するパイプラインを追加。
    - `speech align` の `[start - end] word` 出力をパースし、単語時刻を元のTXT歌詞行へ戻す `ForcedAlignerLineMapper` を追加。
    - `UX_MUSIC_LYRICS_SYNC_ALIGNER=auto|qwen3|off`、`UX_MUSIC_LYRICS_SYNC_ALIGNER_BIN`、`UX_MUSIC_LYRICS_SYNC_ALIGNER_MODEL` を追加。
    - `auto` では `speech` CLI が利用可能なときだけ強制アラインメントを優先し、失敗時は既存 WhisperKit 経路へフォールバック。
- **テスト追加**:
    - `swift/lyrics-sync/Tests/LyricsSyncCLITests/ForcedAlignerPipelineTests.swift` に、aligner出力パースと単語時刻から歌詞行への復元テストを追加。
- **検証**:
    - `swift test --package-path swift/lyrics-sync`
    - `go test ./internal/lyricssync`
    - `go test ./...`
    - `npm run typecheck`（`src/renderer`）
    - `npm test`（`src/renderer`）
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-12a` に更新。
    - `src/renderer/package.json` / `src/renderer/package-lock.json` のバージョンを `1.0.0-Beta-9a` に更新。

## 2026年5月28日

### レビュー指摘順にセキュリティ・再生系不具合を修正

- **不具合内容**:
    - Wear API が LAN に認証なしで公開され、曲一覧・音源取得・再生操作へアクセス可能だった。
    - Wails の `/safe-media/` がライブラリ登録外のローカルファイルも配信し得る状態だった。
    - `/safe-artwork/` と `GetArtworkAsDataURL()` にアートワーク保存領域外を参照する余地があった。
    - プレイリスト名にパス区切りや `..` を含めると、`Playlists` ディレクトリ外を操作し得た。
    - ノーマライズ画面でファイル名を `innerHTML` へ直接差し込んでいた。
    - `profile=fast` の自動歌詞同期でも Go 側が `medium` を強制し、Swift 側の軽量モデル選択が効いていなかった。
    - Wails ビルド成果物に Swift sidecar を同梱する導線がなく、配布後に Swift runtime を優先できない可能性があった。
    - Wails バックエンド再生ではスキップ統計が `<audio>` 要素依存で記録されなかった。
    - AudioGraph 切替時に保存済み EQ が新しい graph へ再適用されなかった。
    - 右サイドバー映像プレビューの `/safe-media/` URL が `?` や `%` を含むパスで壊れ得た。
- **修正内容**:
    - Wear ペアリング URL に認証トークンを含め、実データ・操作 API は token / `X-UX-Music-Token` / Bearer 認証を必須化。
    - Wails AssetHandler を `asset_handler.go` に分離し、`/safe-media/` はライブラリ登録済みパスのみ許可。
    - アートワーク解決を `ResolveArtworkPath()` に統一し、traversal を拒否。
    - プレイリスト名の検証を `internal/playlist` に集約し、パス区切り・空白・`.` / `..` を拒否。
    - ノーマライズ表示向けの `escapeHtmlText()` を追加。
    - Go 側の `medium` 強制を削除し、未指定モデルは sidecar の profile 選択に委譲。
    - `Makefile build` で `swift build -c release --package-path swift/lyrics-sync` を実行し、`lyrics-sync-swift` を `.app/Contents/Resources/bin` へコピー。
    - Wails/Electron共通の `buildSkipEvent()` を追加し、`getCurrentTime()` / `getDuration()` からスキップ統計を記録。
    - `applyEqualizerToGraph()` を追加し、AudioGraph 切替時にも最後の EQ 設定を再適用。
    - `/safe-media/` URL 生成を path segment ごとの `encodeURIComponent` に変更。
- **テスト追加**:
    - Go: Wear 認証、AssetHandler の safe-media/safe-artwork、アートワーク data URL traversal、プレイリスト名検証、Swift sidecar 同梱候補、`profile=fast` モデル選択。
    - Vitest: ノーマライズHTMLエスケープ、Wailsスキップ統計、EQ graph 適用、safe-media URL エンコード。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-11a` に更新。
    - `src/renderer/package.json` のバージョンを `1.0.0-Beta-8a` に更新。

## 2026年5月15日

### 長時間一時停止後に再生再開できない不具合を調査・修正

- **不具合内容**:
    - Wails バックエンド再生で、一時停止して数時間放置したあと、同じ曲の再生再開ができない状態になっていた。
    - 他の曲をクリックすると再生できるため、曲データではなく出力ストリームの復旧経路が疑わしい状態だった。
- **原因**:
    - `pkg/audio/player.go` の `Resume()` が `paused` フラグを戻すだけで、PortAudio ストリームの `Start()` 再実行や開き直しを行っていなかった。
    - 長時間アイドルやスリープ復帰で OS 側のストリームが停止・無効化された場合、UI は再開扱いでも実音声が戻らない可能性があった。
- **修正内容**:
    - 出力ストリームを `audioStream` インターフェース化し、再開処理を単体テスト可能にした。
    - 短時間の `Resume()` では既存ストリームの `Start()` を再実行し、既に開始済みの場合は正常扱いにした。
    - 30分以上一時停止していた場合は PortAudio ストリームを停止・クローズして開き直すようにした。
- **テスト追加**:
    - `pkg/audio/player_resume_test.go` に、既存ストリーム再起動と長時間停止後のストリーム再作成を検証するテストを追加。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.ts` のバージョンを `0.1.9-Beta-10b` に更新。
    - `src/renderer/package.json` のバージョンを `1.0.0-Beta-6f` に更新。

## 2026年3月15日

### コンソール向けパフォーマンスモニターを追加

- **要望対応**:
    - GUI ではなく、5秒ごとの平均負荷をコンソールに出力する軽量なパフォーマンスモニターを追加した。
- **実装内容**:
    - `app_perf.go` を追加し、Wails バックエンドから `RSS`、`CPU`、`Go heap`、`goroutine` 数などを取得できる `GetPerformanceSnapshot()` を実装。
    - `src/renderer/js/utils/performance-monitor.js` を追加し、1秒ごとにサンプルを集め、5秒平均で `RSS`、`CPU`、`GoHeap`、`JSHeap`、`FPS`、`DOM` ノード数、キュー件数、歌詞行数をコンソールへ出力。
    - `src/renderer/renderer.js` で起動時にモニターを開始するよう追加。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-9d` に更新。

## 2026年3月15日

### 同期歌詞の行位置が重なって残る不具合を修正

- **不具合内容**:
    - アクティブ行の切替後、表示済み歌詞が同じ場所に溜まるように重なって残っていた。
- **原因**:
    - 歌詞の縦位置は「現在のアクティブ行」を基準に全行で再計算する必要があるが、差分更新化した処理では一部行しか `transform` を更新していなかった。
- **修正内容**:
    - `src/renderer/js/features/lyrics-manager.js` の `applyLyricsMotionByIndex()` を修正し、アクティブ行変更時は全行の位置・不透明度・ぼかし・ハイライト状態を一括で再計算するように戻した。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-9c` に更新。

## 2026年3月15日

### 同期歌詞ハイライトの重なりを修正

- **不具合内容**:
    - 同期歌詞のアクティブ行が解除されず、再生進行にあわせてハイライトが重なって残り続ける状態になっていた。
- **原因**:
    - `src/renderer/js/features/lyrics-manager.js` の差分更新処理で、前回のアクティブ行インデックスを参照する前に現在値で上書きしていた。
- **修正内容**:
    - `applyLyricsMotionByIndex()` で前回のアクティブ行を先に退避し、その値を使って差分更新するよう修正。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-9b` に更新。

## 2026年3月15日

### パフォーマンス最適化を実施

- **要望対応**:
    - `markdown/optimise.md` の計画に基づき、再生中ホットパス、RAM 常駐構造、ライブラリ更新処理の最適化を進めた。
- **実装内容**:
    - `src/renderer/js/ui/player-ui.js` で音量スライダーの即時反映と設定保存を分離し、入力中の永続化連打を停止。
    - `src/renderer/js/ui/ui-manager.js` と `src/renderer/js/ui/element-factory.js` で再生キューの差分更新、ライブラリ索引の導入、アルバム/アーティストの `songIds` 管理、追加曲の増分集計を実装。
    - `src/renderer/js/features/visualizer.js` で Wails 周波数データ取得を固定間隔へ間引き。
    - `src/renderer/js/features/lyrics-manager.js` で歌詞現在行探索を高速化し、行切替時の DOM 更新を局所化。
    - `src/renderer/js/features/audio-graph.js` で AudioGraph キャッシュ数を制限し、不要な AudioContext を破棄するよう変更。
    - `src/renderer/js/features/player.js` で Media Session アートワークを軽量なサムネイル中心へ変更し、大きな Data URL 保持を回避。
    - `src/renderer/js/core/state.js`、`src/renderer/js/core/navigation.js`、`src/renderer/js/ui/detail-renderer.js`、`src/renderer/js/ui/grid-renderer.js` などを更新し、表示中曲管理を `currentlyViewedSongIds` 基準へ移行。
    - `src/renderer/renderer.js` で `artworkLoadTimes` を固定長バッファ化。
- **検証**:
    - 変更したフロントエンド JavaScript 群に対して `node --check` を実行。
    - `git diff --check` を実行し、空白系の差分不備がないことを確認。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-9a` に更新。

## 2026年3月10日

### 再生バー音声情報: ビットレート表示をビット数表示へ変更

- **要望対応**:
    - 音声情報ツールチップの2項目目を「ビットレート」から「ビット数（ビット深度）」へ変更した。
- **実装内容**:
    - `src/renderer/index.html` のラベルとDOM IDを `audio-info-bit-depth` へ変更。
    - `src/renderer/js/ui/player-ui.js` で `bitrate` 整形処理を削除し、`bitDepth` / `bitsPerSample` / `bitsPerRawSample` / `sample_fmt` を使ったビット深度表示へ変更。
    - `internal/scanner/ffprobe.go` で `bits_per_sample` / `bits_per_raw_sample` / `sample_fmt` からビット深度を抽出し、`probedMetadata.BitDepth` に保持。
    - `internal/scanner/scanner.go` と `app_scanner.go` に `bitDepth` の保持・マージ処理を追加。
- **テスト追加**:
    - `internal/scanner/ffprobe_test.go` に、`sample_fmt` と `ffprobeStream` からビット深度を抽出する単体テストを追加。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8y` に更新。

## 2026年3月10日

### 再生バー: 音声情報ツールチップを追加

- **要望対応**:
    - シークバーと音量コントロールの間に情報ボタンを追加し、マウスオーバーで音声メタ情報を表示できるようにした。
- **実装内容**:
    - `src/renderer/index.html` に情報ボタン（`audio-info-btn`）とツールチップ（`audio-info-tooltip`）を追加。
    - `src/renderer/styles/components.css` に、情報ボタンのスタイルとホバー/フォーカス時に表示されるツールチップUIを追加。
    - `src/renderer/js/ui/player-ui.js` に、再生中キューから `sampleRate` / `bitrate` / `fileType` を整形する処理を追加。
    - `bitrate` が直接取得できない場合は `fileSize` と `duration` から推定（`~xxx kbps`）するフォールバックを実装。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8x` に更新。

## 2026年2月27日

### WAVシーク不能と未解析曲スキップを修正（Wails build互換）

- **不具合内容**:
    - WAVファイルでシーク操作が効かず、再生位置を移動できない状態だった。
    - `wails build` 後のアプリで未解析曲を再生すると、ラウドネス解析失敗時に「破損」扱いで次曲へスキップされていた。
- **原因**:
    - `pkg/audio/player.go` の WAV 実装で、長さ計算に `PCMLen` が正しく反映されない初期化順と、PCM先頭基準ではない `Seek` が混在していた。
    - `pkg/normalize/normalizer.go` の `ffmpeg` 解決が `PATH` 依存で、`wails build` の限定環境で解析が失敗しやすかった。
    - 解析失敗時のフロント分岐が「再生フォールバック」ではなく「次曲スキップ」固定だった。
- **修正内容**:
    - `pkg/audio/player.go` の WAV デコーダ初期化で `FwdToPCM` 実行後に PCM 開始位置・PCMバイト長を保持し、`Seek` を PCM 基準へ修正。
    - `Seek` 実行時に `PCMChunk` を再構築し、シーク後の読み出し継続を保証。
    - `pkg/normalize/normalizer.go` のコマンド探索を強化し、`.app/Contents/Resources` と Homebrew 標準パスをフォールバック探索対象に追加。
    - `src/renderer/js/core/ipc.js` で解析失敗時の挙動を「ノーマライズなし再生」へ変更し、曲スキップを回避。
- **テスト追加**:
    - `pkg/audio/player_wav_test.go` に WAV 長さ計算と WAV シーク位置の単体テストを追加。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8r` に更新。

## 2026年2月25日

### Wails build後の m4a/mp4 再生失敗を修正（ffmpeg探索強化）

- **不具合内容**:
    - `wails dev` では再生可能だが、`wails build` 後の `.app` 起動時に `m4a/mp4` が再生失敗し、次曲へスキップされる状況が発生。
- **原因**:
    - `pkg/audio/player.go` の `ffmpeg/ffprobe` 解決が `exec.LookPath`（`PATH`）依存だったため、Finder 起動時などの限定PATH環境で外部コマンドを見失っていた。
- **修正内容**:
    - `pkg/audio/player.go` の `resolveCommandPath` を強化し、次の順で探索するよう変更。
      - 明示設定された `config.FFmpegPath` / `config.FFprobePath`（実行可能判定付き）
      - `PATH` (`exec.LookPath`)
      - `.app` 実行ファイル基準の `../Resources/bin` と `../Resources`
      - `/opt/homebrew/bin`, `/usr/local/bin`, `/opt/local/bin`, `/usr/bin`, `/bin`
    - 解決結果を `sync.Map` でキャッシュし、再探索を抑制。
    - 解決できない場合は `PATH` を含むエラーを返し、診断しやすくした。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8q` に更新。

### 右サイドバー映像: Wailsでの `file://` ブロックを修正

- **不具合内容**:
    - 右サイドバー映像プレビューが `Not allowed to load local resource: file://...` で失敗し、サムネイルのみ表示される状態だった。
- **修正内容**:
    - `src/renderer/js/ui/now-playing.js` の映像プレビューURL生成を修正し、Wails時は `/safe-media/...` を使用。
    - Electron時は従来どおり `file://` を維持し、実行環境で経路を分岐。
    - 読み込み失敗ログを強化し、`songPath` と `sourceURL` を同時出力するよう変更。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8o` に更新。

### 右サイドバー: 映像付きローカル曲の映像プレビュー対応

- **Wails向け映像プレビューを追加**:
    - `src/renderer/js/ui/now-playing.js` に右サイドバー専用のミュート `video` 要素生成ロジックを追加。
    - `mp4/m4v/mov/webm/ogv` をプレビュー対象にし、`file://` URL を安全に組み立てて表示。
- **再生状態への同期**:
    - 既存の `getCurrentTime()` / `isPlaying()` を利用し、プレビュー映像を再生・一時停止・シークへ追従させる周期同期を実装。
    - 楽曲切替時や非映像曲への遷移時にタイマーと映像要素を確実に破棄し、リークや残像を防止。
- **既存挙動との整合**:
    - Electron 経路の `main-player` 表示ロジックは維持し、Wails 時のみ専用プレビュー経路を使用。
    - 既存の `video-mode`（1:1 -> 16:9）切替をそのまま活用。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8n` に更新。

### YouTube字幕: 明示選択時の「字幕なし」誤判定を修正

- **原因特定**:
    - 対象動画 `u74OTPd6W5Q` では字幕トラック自体は存在するが、字幕XMLが `timedtext format=3`（`<body><p t d>`）形式のため、従来の `<text start dur>` 専用パーサーでは空判定になっていた。
    - 同時に `GetTranscript(\"en\")` は `status code: 400` となり、フォールバック経路でも歌詞生成できない状態だった。
- **修正内容**:
    - `internal/youtube/youtube.go` に `parseTranscriptXMLBody` を追加し、`xml-text` / `xml-timedtext-body` の両形式を解析。
    - `loadTranscriptByTrack` にレスポンス種別ログ（status/content-type/bytes）と失敗時スニペットログを追加し、原因追跡を容易化。
- **テスト追加**:
    - `internal/youtube/youtube_test.go` に、旧形式XMLと `format=3` XMLのパース試験を追加。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8m` に更新。

### YouTube字幕: 選択UI追加と詳細ログ強化

- **字幕候補を事前取得して選択可能に**:
    - `internal/youtube/youtube.go` の `GetYouTubeVideoInfo` に字幕候補（言語/ラベル/自動字幕/トラックID）を追加。
    - `src/renderer/js/core/init-listeners.js` で YouTubeリンク入力後に字幕選択モーダルを表示し、`auto / none / 指定字幕` を選択可能にした。
- **ダウンロード payload を拡張**:
    - `src/renderer/js/core/env-setup.js` と `app_youtube.go` を更新し、`add-youtube-link` で `captionMode` / `captionLanguageCode` / `captionVssId` を受け渡し可能にした。
- **デバッグログを追加**:
    - フロント側: 字幕候補取得結果・選択結果・送信 payload をコンソール出力。
    - バック側: 字幕候補列挙・選択モード・候補試行順・取得失敗理由・最終採用字幕をログ出力。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8l` に更新。

### YouTube有効化: confirm依存を廃止してWails互換化

- **同意UIをモーダル化**:
    - `src/renderer/js/ui/modal.js` に `onCancel` を追加し、キャンセル時のコールバックを取得できるように拡張。
    - `src/renderer/js/utils/debug-commands.js` で、Wails 環境時はアプリ内モーダルで同意確認を行うように変更。
- **有効化失敗の解消**:
    - `confirm()` が `false` 返却になって有効化できないケースでも、同意取得後に `enableYouTube` を保存して UI を表示できるよう改善。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8k` に更新。

### YouTube機能有効化: Wails対応の連打導線を追加

- **有効化処理を共通化**:
    - `src/renderer/js/utils/debug-commands.js` に YouTube 有効化同意フローの共通関数を追加。
    - 既存 `uxDebug.enableYouTubeFeatures()` も共通関数を呼ぶ構成へ変更。
- **ライブラリ管理ボタン連打で有効化**:
    - `src/renderer/js/core/init-listeners.js` で「ライブラリを管理」ボタンを 2.5 秒以内に 7 回連打した際、有効化同意ダイアログを表示するように実装。
    - Wails 環境でも画面上の導線だけで有効化できるように改善。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8j` に更新。

### YouTubeダウンロード: 字幕同時取得と同期歌詞（LRC）自動生成

- **字幕取得とLRC変換を追加**:
    - `internal/youtube/youtube.go` に字幕トラック優先ロジック（手動字幕優先、日本語/英語優先）を追加。
    - 字幕セグメントを LRC 形式へ変換し、ダウンロード結果に `lyrics` / `lang` を含めるように変更。
- **Wailsバックエンド導線を追加**:
    - `app_youtube.go` に `AddYouTubeLink` を実装し、YouTubeダウンロード後にライブラリ保存と `scan-complete` イベント通知を実施。
    - 字幕が取得できた場合は `Lyrics` ストアへ `.lrc` を保存し、既存の歌詞表示導線で再利用可能にした。
- **フロント呼び出しを接続**:
    - `src/renderer/js/core/env-setup.js` で `add-youtube-link` を Wails `AddYouTubeLink` に接続。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8i` に更新。

## 2026年2月17日

### Wailsバックエンド再生でイコライザーが効かない不具合を修正

- **Go再生エンジンへ10バンドEQを実装**:
    - `pkg/audio/player.go` に 10 バンド（31Hz〜16kHz）の Biquad フィルタ処理を追加。
    - PortAudio のリアルタイムコールバックでロック不要の係数参照を行う構成にし、`SetEqualizer` で設定を即時反映できるように変更。
- **Wails公開APIを追加**:
    - `app_audio.go` に `AudioSetEqualizer` を追加し、フロントエンドから `active` / `preamp` / `bands` を受け取って再生エンジンへ反映。
- **フロント側の適用経路を修正**:
    - `src/renderer/js/features/audio-graph.js` の `applyEqualizerSettings` で、Wails 環境時に Go 側 `AudioSetEqualizer` を呼び出すよう変更。
    - `src/renderer/js/ui/equalizer.js` から `active` フラグ付きで設定を送るように変更し、EQ OFF 時は確実に無効化されるよう修正。
    - `src/renderer/js/features/player.js` の `activateAudioGraph` import 抜けを補完し、ローカル再生経路の回帰も防止。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8h` に更新。

## 2026年2月16日

### 同期歌詞: 拡大演出を維持したまま折り返し位置を安定化

- **拡大演出を復帰**:
    - `src/renderer/js/features/lyrics-manager.js` と `src/renderer/styles/views.css` で `scale(0.9 -> 1)` のモーションを再適用。
- **改行位置が変わる要因を排除**:
    - `font-weight` はアクティブ/非アクティブで固定し、ハイライト切り替え時に文字幅が変わらないよう維持。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8g` に更新。

### 同期歌詞: ハイライト時の折り返し揺れを抑制

- **折り返し位置の安定化**:
    - `src/renderer/js/features/lyrics-manager.js` の LRC モーション適用で、アクティブ時の `scale` 変化を廃止。
    - `src/renderer/styles/views.css` の LRC 行スタイルで、アクティブ/非アクティブ間の `font-weight` 変化をなくし、横方向の文字組みが変わらないよう調整。
- **視認性は維持**:
    - 強調は `opacity` / `blur` / `text-shadow` 中心に統一し、表示の滑らかさを優先。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-8f` に更新。

### 自動歌詞同期: MLボーカル抽出のmacOS加速とフォールバック改善

- **demucs 実行デバイス制御を追加**:
    - `internal/lyricssync/vocal_ml.go` で `--device` 指定を追加。
    - Apple Silicon（`darwin/arm64`）では `mps` を優先し、失敗時は `cpu` へ自動フォールバック。
    - `UXMUSIC_LYRICS_SYNC_DEMUCS_DEVICE` 環境変数で実行順を上書き可能（例: `mps,cpu`）。
- **フォールバック耐性の向上**:
    - モデル候補（`*_q` など）ごとにデバイス候補を切り替え、失敗時のリトライ精度を改善。
    - `diffq` 未導入時は既存どおり非量子化モデルへ切替。
- **テスト拡充**:
    - `internal/lyricssync/vocal_ml_test.go` にデバイス候補生成テストと `mps -> cpu` フォールバック試験を追加。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-7w` に更新。

### LRCエディタ: タイムライン編集UIと既存LRC再編集対応

- **タイムライン編集を追加**:
    - `src/renderer/components/lrc-editor.html` に、ルーラー・プレイヘッド・クリップ表示を持つタイムライン領域を追加。
    - `src/renderer/styles/lrc-editor.css` に、クリップ表示・ドラッグ中表示・未配置行表示のスタイルを追加。
- **編集ロジックを刷新**:
    - `src/renderer/js/features/lrc-editor.js` で、歌詞クリップのドラッグによる時刻微調整を実装。
    - タイムラインクリックによるシーク、再生位置プレイヘッド同期、未配置行一覧からの行選択に対応。
    - 既存 `.lrc` のメタタグ（`[ar:]` など）を保持し、保存時に再出力するよう変更。
    - 複数タイムスタンプ付きLRC行を編集用に展開して読み込み可能に変更。
- **導線改善**:
    - `src/renderer/js/features/lyrics-manager.js` を更新し、LRC表示中でも右クリックから「同期歌詞を編集...」を開けるよう変更。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-7x` に更新。

### LRCエディタ: オブジェクト伸縮編集とルーラー倍率変更

- **AviUtlライク編集を追加**:
    - `src/renderer/js/features/lrc-editor.js` でクリップ中央ドラッグの移動ロジックを拡張。
    - 左右端ハンドルを追加し、左端で開始位置、右端で終了境界（次行時刻）を伸縮できるように変更。
- **ルーラーズームを追加**:
    - `src/renderer/components/lrc-editor.html` に倍率スライダーを追加。
    - `src/renderer/styles/lrc-editor.css` にズームUI・横スクロールタイムライン・ハンドルスタイルを追加。
    - `src/renderer/js/features/lrc-editor.js` で倍率に応じたルーラー密度・描画幅切り替えを実装。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-7y` に更新。

### LRCエディタ: ドラッグ時のルーラー不要移動を抑制

- **ドラッグ開始時のスクロール制御を修正**:
    - `src/renderer/js/features/lrc-editor.js` の `setActiveLine` にスクロール制御オプションを追加。
    - クリップのドラッグ開始時は `scrollIntoView` を無効化し、タイムライン（ルーラー）が意図せず動かないように調整。
- **仕様同期とバージョン更新**:
    - `markdown/requirement.md` / `src/renderer/js/core/bridge.js` のバージョンを `0.1.9-Beta-7z` に更新。

## 2025年10月11日

### ユーザーからの依頼
- 音楽プレイヤーに隠し機能としてクイズ機能を追加したい。
- Androidの開発者向けオプションのように、設定画面の特定の箇所を複数回タップすると機能が解放されるようにしたい。

### 実装内容
- **隠し機能のトリガー**: 設定モーダルのタイトル「設定」を7回クリックすると、サイドバーに「クイズ」メニューが表示されるロジックを実装。
- **UIの追加**:
    - `src/renderer/index.html`: サイドバーに非表示の「クイズ」メニューと、クイズ画面のコンテナ(`quiz-view`)を追加。
    - `src/renderer/renderer.js`: 設定タイトルのクリックイベントを監視し、7回クリックでクイズメニューを表示する処理を追加。
    - `src/renderer/js/navigation.js`: `showView`関数を修正し、`quiz-view`への画面切り替えに対応。

### 課題・つまづき
- 特になし。基本的なUIの枠組みとトリガーの追加を完了。

---

## 2025年10月12日

### ユーザーからのフィードバック
1. HTML内のコメントが画面にテキストとして表示されてしまう。
2. UI上のテキストが選択可能になっており、操作性を損なっている。

### 実装内容
- **HTMLコメントの削除**: `src/renderer/index.html` から、画面に表示されてしまっていたHTMLコメントをすべて削除。
- **テキスト選択の無効化**: `src/renderer/styles/base.css` の`body`セレクタに `user-select: none;` を追加し、アプリケーション全体のテキストを選択不可にした。

### 課題・つまづき
- 特になし。フィードバックに基づき、UIの微調整を実施。

---

## 2025年10月13日

### ユーザーからのフィードバック
- 他の画面からクイズ画面に遷移すると、以前の画面（アルバム一覧など）がクイズ画面の背後に残って表示されてしまう。

### 実装内容
- **画面遷移ロジックの修正**: `src/renderer/js/navigation.js` の `showView` 関数を修正。
    - クイズ画面のような特別なビューに切り替える際に、メインコンテンツ領域(`main-content`)を非表示にし、中身をクリアする処理(`clearMainContent()`)を追加。
- **`view-renderer.js`の修正**:
    - `clearMainContent`関数を外部のモジュールから呼び出せるように`export`キーワードを追加。

### 課題・つまづき
- 画面の描画管理が`navigation.js`と`view-renderer.js`にまたがっており、状態の不整合が起きやすい構造になっていた。責務を明確化し、`navigation.js`が全体の表示/非表示を管理し、`view-renderer.js`がコンテンツの描画とクリアに専念するよう修正した。

---

## 2025年10月14日

### ユーザーからの依頼
- クイズの具体的な内容として、イントロクイズ（曲名を当てる4択形式）を実装してほしい。
- 将来的に再生数に応じた難易度調整も視野に入れたい。

### 実装内容
- **クイズUIの実装**: `src/renderer/index.html`に、開始画面、問題画面、結果表示画面のUI要素を追加し、`src/renderer/styles/views.css`でスタイリング。
- **クイズ機能のコアロジック実装**:
    - `src/renderer/js/quiz.js`を新規作成。
    - ライブラリからランダムに4曲を選び、問題（正解1曲、不正解3曲）を生成するロジックを実装。
    - `new Audio()`を使用して、メインの音楽プレーヤーとは独立したイントロ再生機能（冒頭10秒）を実装。
- **各種モジュールの連携**:
    - `renderer.js`で`initQuiz()`を呼び出し、クイズ機能を初期化。
    - `navigation.js`で、クイズ画面から離れる際にイントロ再生が停止するよう`stopQuiz()`を呼び出す処理を追加。

### 課題・つまづき
- メインの音楽プレーヤー(`main-player`)とクイズ用の`Audio`オブジェクトが干渉しないように、クイズの音声を再生する前にメインプレーヤーを一時停止させる処理を追加した。

---

## 2025年10月15日 (1回目)

### ユーザーからの改善案
1. クイズの音量をメインプレーヤーの音量と同期させたい。
2. 回答までにかかった時間を計測・表示したい。
3. 問題数を10問、20問、30問から選択できるようにしたい。
4. スペースキーでイントロを再生できるようにしたい。
5. 別アルバムに収録された同じ曲（同アーティスト・同タイトル）が選択肢に重複しないようにしたい。

### 実装内容
- **UIの機能拡張**: `src/renderer/index.html`と`src/renderer/styles/views.css`を更新。
    - 問題数選択用のラジオボタン、タイマー表示、最終結果画面（スコア・平均時間）を追加。
- **クイズロジックの強化**: `src/renderer/js/quiz.js`を大幅に更新。
    - **音量同期**: `volumeSlider`の値を`quizAudio.volume`に設定。
    - **タイマー機能**: `performance.now()`を使用して、再生開始から回答までの時間を計測。
    - **問題数選択**: 開始画面で選択された問題数を`quizState`に保存。
    - **重複排除**: 問題を生成する際に、同アーティスト・同タイトルの曲が選択肢に含まれないように重複チェック処理を追加。
- **スペースキー対応**: `renderer.js`の`keydown`イベントリスナーで、クイズ画面表示中に`handleQuizKeyPress`を呼び出すように修正。

### 課題・つまづき
- 曲の重複排除ロジックが少し複雑になったが、`Map`オブジェクトを使って`アーティスト名|曲名`をキーにすることで効率的に重複を判定できた。

---

## 2025年10月15日 (2回目)

### ユーザーからの改善案
1. イントロ再生を途中で止められないようにしたい。
2. 再生回数に基づいた難易度（かんたん/ふつう/むずかしい）を選択できるようにしたい。
3. クイズの結果をランキング形式で保存・表示したい。
4. `renderer.js`と`views.css`が長くなりすぎたのでリファクタリングしてほしい。
5. （追加要望）スペースキーで次の問題に進めるようにしたい。

### 実装内容
- **リファクタリング**:
    - `renderer.js`からイベントリスナーと設定関連の処理を`init-listeners.js`と`init-settings.js`に分離。
    - `views.css`からクイズ関連のスタイルを`quiz-view.css`に分離。
- **難易度とランキング機能の実装**:
    - `quiz.js`: 難易度に応じて`getQuizSongs`関数が出題リストをフィルタリング（再生回数を参照）するように修正。
    - `ipc-handlers.js`, `system-handler.js`: クイズのスコアを`quiz-scores.json`に保存・読み込みするためのIPCハンドラ`save-quiz-score`, `get-quiz-scores`を追加。
    - `data-store.js`: `quiz-scores.json`が空の場合でも、エラーにならないよう空の配列を返すように修正。
- **操作性の向上**:
    - `quiz.js`:
        - `playSnippet`関数から再生を停止するロジックを削除。
        - `handleQuizKeyPress`関数を修正し、解答表示後にスペースキーを押すと次の問題へ進めるようにした。

### 課題・つまづき
- **起動時エラー**: リファクタリングの際に`renderer.js`の`import`文が不足し、`elements is not defined`エラーが発生。`import { elements } from './js/state.js'`を追加して修正。
- **クイズ終了時エラー**: `quiz-scores.json`が空の時に`scores.push`が失敗するエラーが発生。`data-store.js`が空ファイルに対して`{}`を返していたのが原因。配列を期待するファイルの場合は`[]`を返すように修正。
- **プレイリスト表示問題**: 起動時にプレイリストが空になる問題が発生。IPC通信のタイミングを調整し、ライブラリ読み込み完了後にプレイリストを要求するように修正して解決。

## 2025年11月15日

### MTP 転送機能（次期バージョン）

| ステータス | 機能 |
| :---: | :--- |
| 〇 | MTPデバイス（Walkman）の認識 (macOS) |
| 〇 | ストレージ情報の取得 (macOS) |
| 〇 | ファイル転送（アップロード）の基本実装 (macOS) |
---

## 2026年1月20日

### プロジェクト情報のドキュメント同期

- **ドキュメントの最新化**:
    - `requirement.md`: CDリッピング、MTP転送、ムード解析の最新情報を追記。バージョンを `0.1.9-Beta-5c` へ更新。
    - `features.md`: 実装済み機能リストを整理。
    - `document.md`: `cd-rip-handler.js` や `mood-analyzer.js` などの新規ファイルの説明を追加。
    - `roadmap.md`: 完了済み項目の整理と次期目標の更新。
- **バージョン情報の更新**:
    - `package.json`: バージョンを `0.1.9-Beta-5j` にカウントアップ。

### ビジュアライザーの調整

- **バーの伸長抑制**:
    - `src/renderer/js/visualizer.js`: バーの高さ計算のスケーリング係数を `20` から `12` へ調整。これにより、音が大きい時でもバーがコンテナの上限（20px）に張り付きにくくなり、よりダイナミックな動きを実現。

### 課題・つまづき
- ドキュメントが複数に分散していたため、情報の整合性を保つための精査に時間を要したが、今回の更新で各ドキュメントがソースコードの最新状態と同期された。
- ビジュアライザーの感度が高すぎると、常に最大値付近で動いてしまい視覚的な変化が乏しくなるため、係数の微調整が必要であった。

---

## 2026年1月28日

### プロジェクトの大規模リファクタリング

- **Go バックエンドの構造化**:
    - ロジックを `internal` パッケージ（`config`, `analyzer`, `scanner` 等）に分離。
    - `app.go` を機能別の 9 ファイル（`app_audio.go` 等）に分割し、可読性と保守性を向上。
    - `config` パッケージによる設定管理の一元化。
- **フロントエンド JS の整理**:
    - `src/renderer/js` 内のファイルを `core`, `features`, `ui`, `utils` ディレクトリへ分類。
    - 全ての相対インポートパスを新構造に合わせて修正。
- **ビルド・検証**:
    - `wails build` が正常に完了することを確認。
    - バージョンを `0.1.9-Beta-5k` へ更新。

---

## 2026年2月15日

### Wails 移行中のメタデータ読込改善

- **m4a メタデータ読込の強化**:
    - `internal/scanner/scanner.go`: `tag` で取得できない項目を `ffprobe` で補完する処理を追加。
    - `internal/scanner/ffprobe.go`: タイトル・アーティスト・アルバム・アルバムアーティスト・年・ジャンル・トラック番号・ディスク番号・再生時間・サンプルレートの抽出を実装。
- **ジャケット抽出の強化**:
    - `internal/scanner/artwork.go`: `tag.Picture()` で取得できない場合に `ffmpeg` で埋め込み画像（attached picture）を抽出するフォールバックを追加。
    - `ffmpeg` / `ffprobe` のパス解決を設定値優先 + `PATH` フォールバックへ変更し、Wails 環境でも実行可能に改善。
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-5t` に更新。

### ノーマライザー機能の Wails 互換修正

- **移行で欠落していたブリッジの復元**:
    - `src/renderer/js/core/env-setup.js` に `start-normalize-job` の `send` ルートを追加。
    - `select-files-for-normalize` / `select-folder-for-normalize` / `get-library-for-normalize` / `get-all-loudness-data` / `select-normalize-output-folder` の `invoke` ルートを Wails 側へ追加。
- **Go 側ジョブ処理の互換性修正**:
    - `app_normalize.go` で `options` の構造（`backup` / `output` / `basePath`）を解釈する実装に変更。
    - 解析結果イベント名を Electron 互換の `analysis-result` に統一（`normalize-result` は継続）。
    - ノーマライズ画面から使う API（ファイル選択、フォルダ再帰走査、ライブラリ読込、ラウドネス一括取得、出力先選択）を追加。
- **FFmpeg 解決の耐障害性向上**:
    - `pkg/normalize/normalizer.go` で `config` 未設定時も `PATH` から `ffmpeg` を解決するフォールバックを追加。
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-5u` に更新。

### ラウドネス永続化の修正

- **`loudness.json` への保存を復元**:
    - `app_normalize.go` の `NormalizeAnalyze` と `NormalizeStartJob(jobType=analyze)` で解析成功時に `loudness` ストアへ保存する処理を追加。
    - `GetLoudnessValue` / `GetAllLoudnessData` で安全なロード関数を使うように変更し、空ファイル時も安定動作。
- **再生時のラウドネス解析イベントを Wails に接続**:
    - `src/renderer/js/core/env-setup.js` に `request-loudness-analysis` の Wails 分岐を追加。
    - `NormalizeAnalyze` の結果を `loudness-analysis-result` としてフロントへイベント送信するように修正。
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-5v` に更新。

### Wails 再生前ラウドネス解析の有効化と安全対策

- **再生前ラウドネス解析の有効化**:
    - `src/renderer/js/features/playback-manager.js` で Wails 環境でも `request-loudness-analysis` を発行するように変更。
    - 解析完了までの「再生準備中」通知と待機フローを Wails でも有効化。
- **解析失敗時イベントの補完**:
    - `src/renderer/js/core/env-setup.js` の `request-loudness-analysis` 失敗時に `loudness-analysis-result`（`success: false`）を emit するよう修正。
- **元音源消失リスクの低減**:
    - `src/renderer/js/ui/list-renderer.js` の「ライブラリから削除」をライブラリ上の削除のみ（`DeleteSongs(..., false)`）に変更。
    - 削除確認文言から「ファイルも削除」を除去。
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-5w` に更新。

### D&D インポート時の実ファイルコピー対応

- **D&D 取り込みフローの修正**:
    - `app_scanner.go` で、スキャンした曲をライブラリフォルダ（`settings.libraryPath`）配下へコピーしてからライブラリへ登録する処理を実装。
    - 保存先は `アーティスト/アルバム/ファイル名` 構成（ファイル名はサニタイズ）とし、同一保存先の重複取り込みを抑制。
    - `libraryPath` 未設定時は初回取り込み時にフォルダ選択ダイアログを表示し、設定へ保存する処理を追加。
- **ライブラリパス設定操作の Wails 接続**:
    - `src/renderer/js/core/env-setup.js` に `set-library-path` の Wails 分岐を追加。
    - Go 側 `SetLibraryPath()` を呼び出して `settings.libraryPath` を更新可能にした。
- **元音源削除リスクの追加対策**:
    - `src/renderer/js/core/init-listeners.js` の選択削除（ショートカット経路）も、実ファイル削除なしに統一。
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-5x` に更新。

### ライブラリ末尾曲の再生ハイライト不整合修正

- **ライブラリ曲IDの安定化**:
    - `internal/scanner/scanner.go`: `Song` に `id` を追加し、スキャン時の既定値として `path` を設定。
    - `app_scanner.go`: ライブラリへコピー後の保存先パスを `song.id` に反映し、マージ時に `id` を維持するよう修正。
    - `app_playlist.go`: 既存ライブラリ読込時、`id` が欠落している曲へ `path` を補完して保存する移行処理を追加。
- **UI のハイライト判定を一意識別子ベースへ修正**:
    - `src/renderer/js/ui/element-factory.js`: `data-song-id` を `song.id || song.path` で設定。
    - `src/renderer/js/ui/list-renderer.js`: 再生中判定を `id` フォールバック付きで比較。
    - `src/renderer/js/ui/ui-manager.js`: `updatePlayingIndicators()` のセレクタを `id || path` ベースに変更し、ライブラリ追加時も欠落IDを補完。
- **型定義更新**:
    - `src/renderer/wailsjs/go/models.ts`: `scanner.Song` に `id` を追加。
- **検証**:
    - `go test ./...` を実行し、全パッケージで成功（テスト未定義パッケージを除く）。
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-5y` に更新。

### Wails取り込み時の曲ID付与をUUIDへ統一

- **新規取り込み曲のID生成を修正**:
    - `app_scanner.go`: `importSongsToLibrary()` で取り込み後の `song.id` に `uuid` を付与するよう変更。
    - これにより、Wails 経由で追加した曲も `library.json` に `id` が永続化されるように修正。
- **既存ライブラリの欠落ID補完を修正**:
    - `app_playlist.go`: `LoadLibrary()` の移行処理を `path` 補完から `uuid` 補完へ変更。
    - `id` が欠落した過去データを読み込んだ際にも一意IDを生成して保存。
- **依存関係の更新**:
    - `go.mod`: `github.com/google/uuid` を直接依存として追加。
- **検証**:
    - `go test ./...` を実行し、全パッケージで成功（テスト未定義パッケージを除く）。
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-5z` に更新。

### LRC作成機能のWails互換復元

- **歌詞検索ロジックをElectron互換へ調整**:
    - `src/renderer/js/core/env-setup.js`: `get-lyrics` のWails分岐を修正。
    - 検索順を「`song.path` のベース名」→「`song.title`」に変更し、既存の `.lrc/.txt` を見つけやすくした。
- **LRC保存レスポンス形式の互換化**:
    - `src/renderer/js/core/env-setup.js`: `save-lrc-file` のWails分岐を修正。
    - Go呼び出し結果を `{ success: true/false, message }` に正規化し、Electron版のUI期待値に合わせた。
- **LRCエディタ初期化の安定化**:
    - `src/renderer/js/features/lrc-editor.js`: エディタ要素参照をモジュール読込時固定から、開始時の動的解決に変更。
    - 要素未解決時は通知して安全に中断する処理を追加。
    - エディタ再オープン時も `keydown` ハンドラが確実に再接続されるよう調整。
- **検証**:
    - `node --check src/renderer/js/core/env-setup.js`
    - `node --check src/renderer/js/features/lrc-editor.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6a` に更新。

### 各UIでフッターとコンテンツが重なる問題の修正

- **フッター余白計算の実測化**:
    - `src/renderer/js/ui/ui.js`: `updateListSpacer()` を修正。
    - `playback-bar` の実測矩形（`getBoundingClientRect()`）から、ビューポート下端との重なり量を算出して `--footer-height` へ反映するよう変更。
- **通常ビューの下余白を統一**:
    - `src/renderer/styles/layout.css`: `.main-content .view-container` の `padding-bottom` を `--footer-height` へ変更。
- **特殊ビューの下余白を統一**:
    - `src/renderer/styles/normalize-view.css`: `#normalize-view` の下パディングを `calc(20px + var(--footer-height))` に変更。
    - `src/renderer/styles/quiz-view.css`: `#quiz-view` の下パディングを `calc(20px + var(--footer-height))` に変更。
    - `src/renderer/styles/lrc-editor.css`: `#lrc-editor-view` の下パディングを `calc(20px + var(--footer-height))` に変更。
    - `src/renderer/styles/views.css`: `#mtp-transfer-view` の下パディングを `calc(20px + var(--footer-height))` に変更。
    - `src/renderer/styles/mtp-browser.css`: `#mtp-browser-view` に `padding-bottom: var(--footer-height)` を追加。
    - `src/renderer/components/cd-ripper.html`: `.cd-rip-container` の下パディングを `calc(30px + var(--footer-height))` に変更。
- **検証**:
    - `node --check src/renderer/js/ui/ui.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6b` に更新。

### リスト表示のフッター背面スクロール仕様を復元

- **仕様再調整**:
    - 曲リスト等は「フッター背面までスクロールできる」挙動が正であるため、通常ビュー全体への下パディング付与を取り消し。
- **修正内容**:
    - `src/renderer/styles/layout.css`: `.main-content .view-container` の `padding-bottom` を `0px` に戻し、リスト側スペーサー方式（`--footer-height` と末尾スペーサー）を優先する構成へ復元。
    - LRCエディタおよび特殊ビュー側の下余白調整は維持。
- **検証**:
    - `node --check src/renderer/js/ui/ui.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6c` に更新。

### LRCエディタの操作性改善（ハイライト指定・間奏指定）

- **任意行ハイライト機能の追加**:
    - `src/renderer/components/lrc-editor.html`: 「行ハイライト ( H )」ボタンを追加。
    - `src/renderer/js/features/lrc-editor.js`: 選択行にハイライトをトグルする処理を実装。
    - `src/renderer/styles/lrc-editor.css`: 手動ハイライト行とアクティブ行の視認性を強化。
- **間奏指定機能の追加**:
    - `src/renderer/components/lrc-editor.html`: 「間奏挿入 ( I )」ボタンを追加。
    - `src/renderer/js/features/lrc-editor.js`: `[間奏]` 行を挿入する処理を実装。
    - 保存時は通常のLRC行として `[mm:ss.xx][間奏]` 形式で出力されるため、間奏開始位置を明示可能にした。
- **キーボード操作の拡張**:
    - `src/renderer/js/features/lrc-editor.js`: `H` でハイライト切替、`I` で間奏行挿入、`↑/↓` で選択行移動を追加。
- **ヘルプ表記の更新**:
    - `src/renderer/components/lrc-editor.html`: 新しい操作（間奏挿入・行ハイライト）をヘルプへ追記。
- **検証**:
    - `node --check src/renderer/js/features/lrc-editor.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6d` に更新。

### LRCエディタのタイムスタンプ時ハイライト挙動を調整

- **仕様調整**:
    - `T` でタイムスタンプを打った際、次行へ自動移動せず、指定した行をアクティブ（青表示）に維持するよう変更。
    - 「どこに打ったか」を視認しやすくし、歌唱位置の混乱を減らす目的。
- **修正内容**:
    - `src/renderer/js/features/lrc-editor.js`: `addTimestamp()` の自動次行選択ロジックを削除し、現在行を維持する実装へ変更。
    - `src/renderer/components/lrc-editor.html`: ヘルプ文言を実挙動に合わせて更新（行維持と `↑/↓` 移動を明記）。
- **検証**:
    - `node --check src/renderer/js/features/lrc-editor.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6e` に更新。

### LRCエディタのT連打ワークフローに再調整

- **仕様調整**:
    - `T` 1回目: 現在行にタイムスタンプを打ち、青表示をその行に維持。
    - 同じ行が青い状態で `T` を再度押す: 次の歌詞行へタイムスタンプを打ち、青表示を次行へ進める。
    - これにより「今どこを歌っているか」を見失いにくい進行に変更。
- **修正内容**:
    - `src/renderer/js/features/lrc-editor.js`: `addTimestamp()` を連続入力対応ロジックへ変更（同一行連続T時のみ次行へ進行）。
    - `src/renderer/js/features/lrc-editor.js`: 手動行選択（クリック、`↑/↓`）時は自動進行状態を解除するよう調整。
    - `src/renderer/components/lrc-editor.html`: ヘルプ文言を新しいT連打フローに更新。
- **不要機能の整理**:
    - `src/renderer/components/lrc-editor.html` / `src/renderer/js/features/lrc-editor.js` / `src/renderer/styles/lrc-editor.css`: 手動「行ハイライト ( H )」機能を削除。
- **検証**:
    - `node --check src/renderer/js/features/lrc-editor.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6f` に更新。

### LRCエディタの空行間奏仕様へ変更

- **仕様変更**:
    - 空白行挿入ボタンによるスペース文字の疑似空行を廃止。
    - 文字がない行（空行）を間奏扱いとして扱い、`T` でタイムスタンプ付与可能に変更。
- **修正内容**:
    - `src/renderer/components/lrc-editor.html`: 「空白行挿入」ボタンを削除し、ヘルプに「空行も間奏扱いでタイムスタンプ可能」を追記。
    - `src/renderer/js/features/lrc-editor.js`: `insertBlankLine()` と関連リスナーを削除。
    - `src/renderer/js/features/lrc-editor.js`: LRC/TXT/テキストエリアの読込時に空行を `' '` ではなく `''` で保持するよう統一。
    - `src/renderer/js/features/lrc-editor.js`: `addTimestamp()` の空行スキップ制御を削除し、空行を含めて次行へ進行するよう調整。
    - `src/renderer/js/features/lrc-editor.js`: `isInterludeText()` で空行を間奏行として判定するよう変更。
- **検証**:
    - `node --check src/renderer/js/features/lrc-editor.js`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6g` に更新。

### 歌詞表示の追従スクロール中心を可視領域基準へ調整

- **仕様調整**:
    - 再生中の歌詞ハイライト行は、フッター重なり領域を除いた可視範囲の中心へ追従させる。
    - 「フッターに完全に隠れてからスクロール」する遅れを解消。
- **修正内容**:
    - `src/renderer/js/features/lyrics-manager.js`: `--footer-height` とビューポート座標から、歌詞ビューの実可視領域を算出する処理を追加。
    - `src/renderer/js/features/lyrics-manager.js`: LRCのアクティブ行更新時、従来の可視判定分岐を廃止し、実可視領域の中心へ常時スクロール補正するよう変更。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6h` に更新。

### 歌詞表示を Apple Music 風に調整（見た目・追従スクロール）

- **UIスタイルの改善**:
    - `src/renderer/styles/views.css`: 歌詞表示を専用スタイルへ分離し、左右余白を `clamp()` で最適化。
    - 非アクティブ行の減光とアクティブ行の強調（グラデーション・影・スケール）を追加し、視線誘導を改善。
    - 歌詞行をテキスト幅ベース（`width: fit-content`）で表示し、全幅ハイライトによる左右の不自然な空白感を解消。
    - 上下フェード（mask）と小画面向けのフォント/余白調整を追加。
- **追従スクロールの改善**:
    - `src/renderer/js/features/lyrics-manager.js`: アクティブ行の目標スクロール位置を算出する `getLyricsScrollTarget()` を追加。
    - `scrollTop += ...` を廃止し、`scrollTo({ behavior: 'smooth' })` ベースで中心追従するよう変更。
    - 連続更新時の過剰スクロールを抑える差分判定を追加し、体感の滑らかさを向上。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6i` に更新。

### 歌詞表示アニメーションの「ぬるっと感」を強化

- **スクロール追従の改善**:
    - `src/renderer/js/features/lyrics-manager.js`: `requestAnimationFrame` ベースの独自イージングスクロールを追加。
    - アクティブ行の更新時は既存アニメーションを中断し、最新ターゲット位置へ再補間するよう変更。
    - `prefers-reduced-motion` 時は即時スクロールへフォールバックするよう対応。
- **視覚トランジションの改善**:
    - `src/renderer/styles/views.css`: 歌詞行トランジションを 0.52s + `cubic-bezier(0.22, 1, 0.36, 1)` に統一し、移行を滑らかに調整。
    - 非アクティブ行のスケール・不透明度を微調整し、アクティブ行への寄りを自然化。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6j` に更新。

### 歌詞スクロールのガタつき低減とイージング23番対応

- **ガタつき対策**:
    - `src/renderer/styles/views.css`: `#lyrics-view` の `scroll-snap-type` と歌詞行の `scroll-snap-align` を削除し、スクロール追従との干渉を解消。
    - `src/renderer/js/features/lyrics-manager.js`: 微小移動量ではアニメーションを開始しない閾値（`LYRICS_SCROLL_MIN_DISTANCE_PX`）を追加。
- **イージング調整**:
    - `src/renderer/js/features/lyrics-manager.js`: 追従スクロールの補間を `easeOutBack`（イージング23番相当）へ変更。
    - `src/renderer/styles/views.css`: 歌詞行の `transform` トランジションを `cubic-bezier(0.175, 0.885, 0.32, 1.275)` へ変更し、動きの質感を統一。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6k` に更新。

### 歌詞表示をさらにゆったり化し、遅延追従スクロールを追加

- **ゆったりした追従スクロール**:
    - `src/renderer/js/features/lyrics-manager.js`: スクロール時間を固定値から距離依存（最小/最大あり）へ変更し、長距離移動ほどゆっくり追従するよう調整。
    - 微小なスクロール差分は即時反映し、不要なアニメーションを抑えて安定性を維持。
- **遅延追従（ワンテンポ遅れ）演出の追加**:
    - `src/renderer/js/features/lyrics-manager.js`: 歌詞行のラグオフセットを `requestAnimationFrame` で制御する処理を追加。
    - `src/renderer/styles/views.css`: `--lyrics-lag-offset` を導入し、歌詞行の `transform` に反映。アクティブ行は遅延量を軽減して視認性を保持。
    - ラグは「ホールド → 減衰」の2段階で戻すことで、Apple Music 風の後追い感を表現。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6l` に更新。

### 歌詞ハイライト形状の調整と車列風の段階遅延アニメーション

- **ハイライト形状の調整**:
    - `src/renderer/styles/views.css`: アクティブ歌詞のハイライトをピル形状から角丸四角形（`border-radius: 12px`）へ変更。
    - 行パディングを微調整し、Apple Music 風の矩形ハイライトに近づけた。
- **段階遅延（信号待ちの車列）アニメーション**:
    - `src/renderer/js/features/lyrics-manager.js`: 全行一括ラグ方式を廃止し、行ごとに遅延開始する wave 方式へ変更。
    - スクロール方向に応じて行の遅延順を切り替え、前方行から順に動き出す挙動を実装。
    - アクティブ行から離れるほどオフセットを減衰させ、可読性を維持。
    - `src/renderer/styles/views.css`: `--line-lag-offset` / `--line-lag-delay` を導入し、行ごとに異なる追従タイミングを実現。
    - 初期フレーム固定用の `.lag-prime` を追加し、段階遅延開始時のちらつきを抑制。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6m` に更新。

### 歌詞の行間拡張と段階遅延をさらに強調

- **行間と視認性の調整**:
    - `src/renderer/styles/views.css`: 歌詞全体の `line-height` を拡大し、各行の上下余白（`margin` / `padding`）を増加。
    - モバイル幅でも行間が詰まりすぎないように `@media` 側の `line-height` も引き上げ。
- **一行ずつ動く演出の強調**:
    - `src/renderer/js/features/lyrics-manager.js`: wave 遅延パラメータ（ベース遅延・段階遅延・オフセット量）を増やし、前行と後行の差を明確化。
    - 遅延時間を `order` の線形ではなく `order^1.12` の非線形に変更し、後段行ほど明確に遅れて動くよう調整。
    - `src/renderer/styles/views.css`: `transform` トランジション時間を延長し、段階遅延の視覚差を強化。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6n` に更新。

### 元行単位の行間制御と後段遅延の強化

- **元行単位の行間制御**:
    - `src/renderer/js/features/lyrics-manager.js`: LRC 解析時に `sourceLine` を保持し、描画時に `line-break` / `line-continuation` クラスを付与。
    - `src/renderer/styles/views.css`: 同一元行の連続表示は狭め、元行が変わる箇所は広めのマージンを適用するスタイルを追加。
    - これにより、折り返しや同一元行の表示密度を保ちつつ、歌詞行の切れ目を明確化。
- **後段遅延の強化（前行完了に近い感覚）**:
    - `src/renderer/js/features/lyrics-manager.js`: 段階遅延のベース値とステップ値を大幅に増加。
    - 遅延関数を非線形（`order^1.22`）かつ上限付きに変更し、後ろの行ほど目立って遅れる挙動へ調整。
    - 遅延対象距離を絞り、強い段階感を保ちながら極端なロングテールを抑制。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6o` に更新。

### 表示中行基準への変更と同一元行の行間圧縮

- **遅延基準点の変更**:
    - `src/renderer/js/features/lyrics-manager.js`: 可視領域中心に最も近い行を `displayed index` として算出する処理を追加。
    - wave 遅延の基準を `active index` から `displayed index` へ変更し、「今表示している行」を軸に段階遅延が発生するよう調整。
    - スクロール中断・リセット時の表示基準インデックスの状態管理を追加し、方向判定の安定性を改善。
- **同一元行の行間調整**:
    - `src/renderer/styles/views.css`: `line-continuation` の `margin-top` をさらに縮小し、同一元行の連続表示をより詰めた見た目に変更。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6p` に更新。

### 歌詞遅延アニメーションを単純ディレイ方式へ回帰

- **アニメーション方式の回帰**:
    - `src/renderer/js/features/lyrics-manager.js`: 行ごとの wave 遅延（表示基準インデックス/段階遅延）を廃止。
    - 早期段階で採用していた「全体ラグオフセット（`--lyrics-lag-offset`）」方式へ戻し、単純な遅延追従に統一。
    - `animateLyricsLagByDistance()` による「ホールド→減衰」制御へ復元し、スクロール追従との干渉を低減。
- **表示スタイルの整理**:
    - `src/renderer/styles/views.css`: 行単位ラグ用の CSS 変数/クラス（`--line-lag-*`, `.lag-prime`）を削除。
    - 同一元行/行切り替えの行間制御（`line-continuation`, `line-break`）は維持。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6q` に更新。

### 歌詞の追従基準を中央から上固定へ変更

- **追従基準の調整**:
    - `src/renderer/js/features/lyrics-manager.js`: `getLyricsScrollTarget()` の計算基準を「可視領域の中心」から「可視領域の上端」へ変更。
    - 上端貼り付きで見切れないように最小オフセット（`LYRICS_TOP_ANCHOR_OFFSET_PX`）を導入。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6r` に更新。

### 上フェードの緩和と上固定位置の下方オフセット調整

- **表示基準位置の調整**:
    - `src/renderer/js/features/lyrics-manager.js`: 上固定アンカー値 `LYRICS_TOP_ANCHOR_OFFSET_PX` を増加し、表示行がやや下に来るよう調整。
- **フェード量の調整**:
    - `src/renderer/styles/views.css`: 歌詞ビュー上端のマスク勾配を緩和し、上側フェードアウトの強さを低減。
- **改行時の行内行間対策**:
    - `src/renderer/styles/views.css`: `#lyrics-view p` に個別 `line-height` を設定し、長い歌詞が折り返した際の行内間隔が過大になる問題を修正。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6s` に更新。

### 行ごとの遅延増加を再導入（表示中行基準・表示済み除外）

- **遅延ロジックの再構成**:
    - `src/renderer/js/features/lyrics-manager.js`: 単純ディレイ（全体オフセット）方式を廃止し、行ごとの段階遅延方式を再導入。
    - 基準点は「表示中の行」（可視領域上端アンカー付近）として算出する方式に変更。
    - スクロール方向に応じて、表示済み側の行（過ぎた側）を遅延対象から除外するフィルタを追加。
- **CSS 連携の復元**:
    - `src/renderer/styles/views.css`: `--line-lag-offset` / `--line-lag-delay` と `.lag-prime` を復元し、行単位の時間差トランジションへ戻した。
    - 同一元行/行切替の行間制御（`line-continuation`, `line-break`）は維持。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6t` に更新。

### 行ごとの遅延カーブを緩やかに調整

- **遅延カーブの再調整**:
    - `src/renderer/js/features/lyrics-manager.js`: 行ごとの遅延増加が急すぎるため、段階遅延パラメータを緩和。
    - `LYRICS_TRAFFIC_WAVE_STEP_MS` を 280 から 120 へ縮小。
    - `LYRICS_TRAFFIC_WAVE_DELAY_EXPONENT` を 1.18 から 1.08 へ下げ、後段の遅延伸びを抑制。
    - `LYRICS_TRAFFIC_WAVE_MAX_DELAY_MS` を 3200 から 2000 へ下げ、過剰なロングテールを制限。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6u` に更新。

### 少表示行（1〜2行）時の遅延追従を補正

- **表示行数ベースの補正を追加**:
    - `src/renderer/js/features/lyrics-manager.js`: 可視領域内の表示行数を計測する `getVisibleLyricsLineCount()` を追加。
    - 表示行数が 3 行未満のとき、遅延カーブを自動的に緩和する係数（`sparseViewFactor`）を導入。
    - `base delay / step / exponent / max delay` を表示行数に応じて縮小し、1〜2行時の「置いていかれてから動く」印象を軽減。
    - 同時に `peakOffset` も表示行数が少ないほど抑え、視覚的な遅れ感を低減。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6v` に更新。

### スクロールイージングを初速高めの減速型へ変更

- **イージング関数の置換**:
    - `src/renderer/js/features/lyrics-manager.js`: スクロールで使用していた `easeOutBack23`（Back系）を廃止。
    - オーバーシュート由来の引っかかり感を減らすため、`easeOutCubic`（初速高め・終端減速）へ差し替え。
    - `animateLyricsScrollTo()` の進行率計算で新イージングを適用。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6w` に更新。

### オーバーシュート挙動（0=>1.2=>1）を解消

- **トランジション曲線の修正**:
    - `src/renderer/styles/views.css`: 歌詞行の `transform` トランジションで使っていた `cubic-bezier(0.175, 0.885, 0.32, 1.275)` を廃止。
    - 終端で 1 を超えない `cubic-bezier(0.22, 1, 0.36, 1)` へ統一し、`0 => 1` の単調遷移に変更。
    - これにより「一瞬上に上がってから落ちる」上振れ挙動を除去。
- **検証**:
    - `rg "1.275" src/renderer/styles/views.css`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6x` に更新。

### 距離に応じた可変速度追従へ変更

- **遅延主体から速度主体へ移行**:
    - `src/renderer/js/features/lyrics-manager.js`: 行ごとの動きを単純な段階遅延から、距離依存の可変速度制御へ変更。
    - 「基準行から遠い行ほど速く戻る」ように、`distance ratio` から `speed factor` を算出。
    - 近い行は遅延が残り、遠い行は遅延が小さくなるよう `line delay` を反比例で調整。
    - さらに遠い行ほど `line-lag-duration` を短くし、収束速度を上げる挙動を追加。
    - 少表示行（1〜2行）時の補正は維持し、過度な置いていかれ感を抑制。
- **スタイル連携の拡張**:
    - `src/renderer/styles/views.css`: `--line-lag-duration` を追加し、`transform` トランジション時間を行ごとに受け取るよう更新。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6y` に更新。

### 強調行を固定しつつ背景歌詞をスクロールする遷移へ改善

- **ガタつき対策（切り替え順序の変更）**:
    - `src/renderer/js/features/lyrics-manager.js`: `active` クラスの切り替えを「スクロール開始前」から「スクロール完了時」へ変更。
    - 既存の強調行がある場合は、次行への強調切り替えを保留し、背景歌詞の移動完了後に切り替えるフローを追加。
    - これにより、強調位置が先にガクッと切り替わる見え方を抑え、後ろのテキストだけが流れる印象へ調整。
- **実装詳細**:
    - `animateLyricsScrollTo()` に完了コールバックを追加し、アニメーション終端で `active` を更新。
    - `setActiveLyricsLineByIndex()` を新設して強調切り替え処理を一元化。
    - 連続更新時の古い完了処理を無効化するため、`lyricsActiveSwapToken` を導入。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-6z` に更新。

### 行数差で不安定だった強調切替方式を廃止し表示を簡素化

- **強調切替ロジックの回帰**:
    - `src/renderer/js/features/lyrics-manager.js`: スクロール完了後に `active` を切り替える方式を廃止。
    - `updateSyncedLyrics()` を即時強調切替に戻し、行数差による不自然な遷移を解消。
    - `lyricsActiveSwapToken` / `pendingActiveLyricsIndex` を削除し、分岐を簡素化。
    - `animateLyricsScrollTo()` から完了コールバックを除去。
- **歌詞スタイルの簡素化**:
    - `src/renderer/styles/views.css`: `active` 行のグラデーション背景とボックスシャドウを削除。
    - `active` 行は白文字でクリアに表示し、他行はぼかしと低めの不透明度で背景化。
    - これにより「強調行ははっきり、その他はぼける」見え方へ調整。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7a` に更新。

### 行切り替え時の急なスクロールを連続追従へ変更

- **スクロール制御の平滑化**:
    - `src/renderer/js/features/lyrics-manager.js`: 行切替時のみ移動していた方式を改め、再生時間に応じた連続スクロールへ変更。
    - 現在行から次行までの時間進行を使って目標位置を補間し、次行へ向けて先行的に少しずつ移動するよう調整。
    - `animateLyricsScrollTo()` を再始動型アニメーションから「目標値追従型」に変更し、目標更新時のガクつきを抑制。
    - 行が切り替わった瞬間のみ wave ラグを発火し、常時発火によるノイズを防止。
- **強調表示の扱い**:
    - `active` の切り替えは従来どおり維持しつつ、背景スクロールだけを連続化して急な切替感を軽減。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7b` に更新。

### スクロール開始タイミングを従来基準へ回帰

- **開始タイミングの調整**:
    - `src/renderer/js/features/lyrics-manager.js`: 次行への先行スクロール補間（時間進行ベース）を廃止。
    - スクロール目標は再び「現在アクティブ行の位置」のみに設定し、動き始めのタイミングを従来と同等に戻した。
    - 目標値追従型のスクロール制御は維持し、開始タイミングを遅らせつつ移動自体は滑らかに保つ構成へ調整。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7c` に更新。

### 行切り替えスクロールへイージングを適用

- **切り替え時スクロールの補間を改善**:
    - `src/renderer/js/features/lyrics-manager.js`: 行切り替え時の追従係数に `easeOutCubic` を適用。
    - `animateLyricsScrollTo()` に `switchEasing` オプションを追加し、行切替時だけ明示的なイージングカーブで追従。
    - 通常追従時と切替時で追従係数を分離し、切替スクロールの急な印象を緩和。
    - 切替スクロール完了後は `switchEasing` 状態をリセットし、次の通常追従に復帰。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7d` に更新。

### 行切り替えスクロールをゆったり化

- **追従速度の再調整**:
    - `src/renderer/js/features/lyrics-manager.js`: 行切替時/通常時の `followStrength` をともに低下。
    - 切替時は `0.06 + easedDistanceRatio * 0.17` へ変更し、最大追従速度を抑制。
    - 通常時は `0.09 + distanceRatio * 0.13` へ変更し、全体の追従を穏やかに調整。
    - イージング形状は維持し、テンポ感のみ「クイック」から「ゆったり」へ変更。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7e` に更新。

### 行切り替えのクイック感をさらに抑制

- **切り替え時の速度上限を導入**:
    - `src/renderer/js/features/lyrics-manager.js`: 行切替時/通常時の `followStrength` をさらに低下。
    - 1フレームあたりの移動量に上限（`maxStep`）を追加し、急なジャンプ移動を抑制。
    - 切替時は最大 4.6px、通常時は最大 6.2px に制限して視覚的な「クイッ」を軽減。
- **ラグ演出の発火条件を調整**:
    - `triggerLag` の発火を大きめの移動時（24px超）に限定し、細かい行切替での過剰演出を回避。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7f` に更新。

### ぼかし解除に短いフェードインを追加

- **フォーカス遷移の調整**:
    - `src/renderer/styles/views.css`: `#lyrics-view p` に `--line-focus-delay` を追加。
    - `opacity` / `filter` / `text-shadow` の遷移に `--line-focus-delay` を適用し、ぼかし解除を即時ではなく短い遅延付きで開始。
    - `#lyrics-view p.active` で `--line-focus-delay: 72ms` を設定し、アクティブ化時にわずかなフェードイン感を付与。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7g` に更新。

### 行切替クイック感を復帰し、TXT表示の特殊効果を無効化

- **行切替スクロールのクイック感を復帰**:
    - `src/renderer/js/features/lyrics-manager.js`: 速度抑制のために追加した1フレーム移動量上限を撤去。
    - `followStrength` を以前の値（切替時 `0.06 + easedDistanceRatio * 0.17` / 通常時 `0.09 + distanceRatio * 0.13`）へ復元。
    - wave ラグ発火条件を `LYRICS_SCROLL_MIN_DISTANCE_PX` 基準へ戻し、切替時のテンポ感を復帰。
- **TXT歌詞のエフェクト無効化**:
    - `src/renderer/js/features/lyrics-manager.js`: 歌詞ビューに `lyrics-mode-lrc` / `lyrics-mode-txt` クラスを付与する処理を追加。
    - `clearLyrics()` / `displayNoLyrics()` でモードクラスをリセットし、前曲の表示効果を持ち越さないよう修正。
    - `src/renderer/styles/views.css`: `#lyrics-view.lyrics-mode-txt p` で blur/transform/遅延遷移を無効化し、通常テキスト表示へ変更。
- **検証**:
    - `node --check src/renderer/js/features/lyrics-manager.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7h` に更新。

### CoreML 前提 TXT 自動同期歌詞の追加

- **バックエンド同期サービスの新設**:
    - `internal/lyricssync/` を新規作成し、以下を実装。
      - `syncer.go`: ffmpeg 抽出 → whisper 実行 → 行整列 → 補間 → 単調性補正の統合パイプライン。
      - `whisper_runner.go`: `whisper-cli` 実行、JSONセグメント解析、モデル探索（環境変数優先 + 既定パス）。
      - `align.go`: TXT行と認識セグメントの単調整列、未一致行の補間、逆転時刻の補正。
      - `normalise.go`: 記号/空白除去、全角半角吸収、大小文字吸収の正規化。
      - `types.go`: `Request` / `AlignedLine` / `Result` の I/O 定義。
    - ログプレフィックスを `[Lyrics AutoSync]` で統一。
- **Wails 公開APIの追加**:
    - `app.go`: `lyricsSyncer` を App 構造体に組み込み。
    - `app_lyrics.go`: `AutoSyncLyrics(req lyricssync.Request)` を追加。
- **フロントエンド連携**:
    - `src/renderer/components/lrc-editor.html`: 「自動同期解析」ボタンを追加。
    - `src/renderer/js/features/lrc-editor.js`: `lyrics-auto-sync` invoke、実行中状態、結果反映、通知表示を実装。
    - `src/renderer/styles/lrc-editor.css`: 自動同期ボタンの通常/実行中/無効状態スタイルを追加。
    - `src/renderer/js/core/env-setup.js`: Wails invoke dispatch に `lyrics-auto-sync` を追加。
- **保存方針**:
    - 自動同期はエディタ上のプレビュー反映のみで、既存の「LRCを保存」操作でのみファイル保存される設計を維持。
- **テスト追加**:
    - `internal/lyricssync/normalise_test.go`: 文字正規化と間奏判定。
    - `internal/lyricssync/align_test.go`: 単調整列と補間の挙動。
    - `internal/lyricssync/syncer_test.go`: 空行エラー、CLI未配置、モデル未配置、擬似 `ffmpeg` / `whisper-cli` による結合検証。
- **ドキュメント更新**:
    - `markdown/Task.md`: 本タスクの完了条件を追加。
    - `markdown/features.md`: TXT自動同期解析を機能一覧に追記。
    - `markdown/requirement.md`: CoreML前提の運用条件と仕様を追加。
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7i` に更新。

### 歌詞自動同期のボーカル重視前処理とフォールバック改善

- **症状**:
    - 実機ログで `whisper のセグメント結果が空です` が発生するケースがあった。
    - 同期精度向上のため、伴奏影響を抑えた前処理の要望を受領。
- **対応**:
    - `internal/lyricssync/whisper_runner.go`:
      - `whisper-cli` の JSON 解析を `segments` 形式に加えて `transcription` 形式にも対応。
      - `timestamps` / `offsets` から秒への変換処理を追加。
    - `internal/lyricssync/syncer.go`:
      - 同期前処理にボーカル重視フィルタ音声を追加（帯域制限・コンプレッション・ノイズ低減）。
      - ボーカル重視候補の一致率が低い場合、通常音声候補を追加解析して自動比較。
      - 一致行数と平均信頼度で最良候補を採用するロジックへ拡張。
    - `internal/lyricssync/syncer_test.go`:
      - 候補比較ロジックと補助関数のテストを追加。
    - `internal/lyricssync/whisper_runner_test.go`:
      - `segments` と `transcription` の両 JSON フォーマット解析テストを追加。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
    - `node --check src/renderer/js/features/lrc-editor.js`
    - `node --check src/renderer/js/core/env-setup.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7j` に更新。

### 空白行（前奏・間奏）補間の改善

- **課題**:
    - 空白行が多い区間で、未一致行の補間時に空白が時間配分を取りすぎるケースがあった。
- **対応**:
    - `internal/lyricssync/align.go`:
      - 補間を重み付き方式へ変更。
      - 空白/間奏行（`Source=interlude`）の重みを下げ、歌詞行へ時間配分を優先。
      - 先頭/末尾の補間ステップも空白行で縮小するよう調整。
    - `internal/lyricssync/align_test.go`:
      - 空白行が混在する区間での重み付き補間テストを追加。
      - 一致ゼロ時に空白行ステップが歌詞行より小さくなることを検証。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7k` に更新。

### 前奏（先頭空白行）アンカー改善と低域カット調整

- **課題**:
    - 先頭の空白行がある歌詞で、前奏の時間幅が十分に残らず、最初の歌詞が早めに配置されるケースがあった。
    - ボーカル重視前処理において、人声として不要な低域カット閾値を調整したい要望があった。
- **対応**:
    - `internal/lyricssync/align.go`:
      - 先頭補間ロジックを変更し、先頭行が空白/間奏なら 0 秒アンカーを固定するように修正。
      - 先頭未一致区間を 0 秒〜最初の一致行時刻で重み付き配分し、前奏を潰さない補間に変更。
    - `internal/lyricssync/syncer.go`:
      - ボーカル重視フィルタを `highpass=70Hz` / `lowpass=4500Hz` に調整。
      - 50Hz付近など人声帯域外の低域をより明確に抑制。
    - `internal/lyricssync/align_test.go`:
      - 先頭空白行が 0 秒アンカーになることを確認するテストを追加。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7l` に更新。

### 自動同期の検知テキスト可視化（デバッグ表示）

- **課題**:
    - 自動同期時に `whisper` が実際に何を検知しているかを画面上で確認したい要望があった。
- **対応**:
    - `internal/lyricssync/types.go`:
      - `Result` に `DetectedBy` と `DetectedSegments` を追加し、採用候補と検知セグメントを返せるように拡張。
    - `internal/lyricssync/syncer.go`:
      - 最終採用候補（`vocal-focus` / `plain`）のセグメントを `Result` に格納して返却する処理を追加。
    - `src/renderer/components/lrc-editor.html`:
      - 「検知テキスト表示」ボタンと表示ポップアップを追加。
    - `src/renderer/js/features/lrc-editor.js`:
      - 自動同期結果から `detectedSegments` を保持し、ポップアップで時刻付きテキストを表示する処理を実装。
    - `src/renderer/styles/lrc-editor.css`:
      - 検知テキスト表示ボタンとポップアップのスタイルを追加。
    - `wails generate module`:
      - `lyricssync.DetectedSegment` を含む生成コードを更新。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
    - `node --check src/renderer/js/features/lrc-editor.js`
    - `node --check src/renderer/js/core/env-setup.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7m` に更新。

### 先頭セグメントの無音トリム補正（前奏つぶれ対策）

- **課題**:
    - 実機で、先頭セグメントが `0.00` 開始かつ長尺になり、最初の歌詞行が早すぎる時刻に吸着するケースがあった。
- **対応**:
    - `internal/lyricssync/align.go`:
      - セグメント整列前にアンカー時刻を算出する処理を追加。
      - 先頭セグメントのみ、開始 `0.00` かつ異常長の場合に、テキスト長と推定文字速度から先頭無音ぶんをトリムする補正を実装。
      - 一般ケースは従来どおり `segment.Start` を使用し、副作用を最小化。
    - `internal/lyricssync/align_test.go`:
      - 先頭長尺セグメント時に、先頭空白行を `0` に維持しつつ最初の歌詞行が早すぎないことを検証するテストを追加。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
    - `node --check src/renderer/js/features/lrc-editor.js`
    - `node --check src/renderer/js/core/env-setup.js`
    - `node --check src/renderer/js/core/bridge.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7n` に更新。

### 空白行の時刻吸収を抑制する補間調整

- **課題**:
    - 空白/間奏行がある区間で、未一致歌詞行の時刻が想定より手前に引っ張られるケースがあった。
- **対応**:
    - `internal/lyricssync/align.go`:
      - 補間時に、同一区間内に歌詞行が存在する場合は空白/間奏行の重みを極小値へ切替するロジックを追加。
      - 先頭空白アンカー (`0s`) から最初の一致行までの補間では、右アンカー寄せの tail weight を導入し、先頭歌詞が早まりにくいよう調整。
    - `internal/lyricssync/align_test.go`:
      - 先頭空白 + 先頭歌詞未一致のケースで、歌詞行が過度に早くならないことを確認するテストを追加。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
    - `node --check src/renderer/js/features/lrc-editor.js`
    - `node --check src/renderer/js/core/env-setup.js`
    - `node --check src/renderer/js/core/bridge.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7o` に更新。

### 空白行のみ区間の右アンカー寄せ補間

- **課題**:
    - 空白行のみの区間で、空白行が直前歌詞の直後に配置され、歌詞表示がすぐ空行へ遷移して見える問題があった。
- **対応**:
    - `internal/lyricssync/align.go`:
      - 空白/間奏行のみで構成される補間区間は、右アンカー寄せの tail weight を適用する処理を追加。
      - これにより空白行が前詰めされず、直前歌詞の表示時間を確保。
    - `internal/lyricssync/align_test.go`:
      - 空白行のみ区間で空白タイムスタンプが即時ジャンプ位置にならないことを検証するテストを追加。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7p` に更新。

### 歌詞行先行整列（空白行後段補完）への変更

- **課題**:
    - 空白行が混在することで、未一致歌詞の補間位置が不安定になり、次の空白行に先に飛んで見えるケースがあった。
- **対応**:
    - `internal/lyricssync/align.go`:
      - 整列処理を 2 段階へ変更。
      - 1段階目で歌詞行のみをセグメント整列・補間。
      - 2段階目で空白/間奏行に時刻を補完（右アンカー寄せを維持）。
      - 空白行探索用の補助関数を追加し、前後アンカーがない場合の補間も安定化。
    - `internal/lyricssync/align_test.go`:
      - 「未一致歌詞の次にある空白行へ早跳びしない」回帰テストを追加。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7q` に更新。

### MLボーカル抽出（demucs / カスタム抽出器）対応

- **課題**:
    - 既存の帯域フィルタのみでは伴奏残りが多い曲で認識誤りが発生し、さらなる同期精度向上余地があった。
- **対応**:
    - `internal/lyricssync/vocal_ml.go` を新規追加。
      - `UXMUSIC_LYRICS_SYNC_VOCAL_SEPARATOR` 指定時はカスタム抽出器を実行（`<input> <output>` 引数契約）。
      - 未指定時は `demucs` を自動探索し `--two-stems=vocals` で抽出。
      - 抽出結果を `ffmpeg` で 16kHz/mono WAV に正規化して同期処理へ投入。
    - `internal/lyricssync/syncer.go`:
      - 候補評価を `vocal-ml` → `vocal-focus` → `plain` の順に統合。
      - 候補の一致率・信頼度・優先順位で最良候補を採用する方式に更新。
    - `internal/lyricssync/syncer_test.go`:
      - 候補優先順位（`vocal-ml` 優先）テストを追加。
    - `internal/lyricssync/vocal_ml_test.go` を新規追加。
      - カスタム抽出器経由の成功ケース
      - demucs 経由の成功ケース
      - 抽出器未検出のエラーケース
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7r` に更新。

### demucs 実行パス解決の強化と導入確認

- **課題**:
    - macOS GUI 起動時は `PATH` が限定される場合があり、`demucs` が存在しても検出できないケースがある。
    - Python 3.14 環境では `demucs` 依存が解決しづらい導入エラーが発生した。
- **対応**:
    - `internal/lyricssync/vocal_ml.go`:
      - `resolveDemucsPath()` を追加し、`demucs` の探索順を `UXMUSIC_LYRICS_SYNC_DEMUCS` → `PATH` → `/opt/homebrew/bin/demucs` → `/usr/local/bin/demucs` に拡張。
    - `internal/lyricssync/vocal_ml_test.go`:
      - `UXMUSIC_LYRICS_SYNC_DEMUCS` の有効/無効ケースを検証する単体テストを追加。
    - 実機導入確認:
      - `python3.10 -m pip install demucs==4.0.1` で導入可能なことを確認（Python 3.14 失敗時の代替手順）。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7s` に更新。

### demucs 失敗時の連鎖タイムアウト対策

- **課題**:
    - `demucs` が長時間実行または強制終了された場合、同一 `context` を使い回していたため後続 `whisper` 候補まで `context deadline exceeded` で連鎖失敗していた。
- **対応**:
    - `internal/lyricssync/syncer.go`:
      - タイムアウトを段階分離（ML抽出用・候補解析用）へ変更。
      - 候補解析ごとに新しい `context.WithTimeout` を作成し、前段失敗が後段に波及しないよう修正。
    - `internal/lyricssync/vocal_ml.go`:
      - demucs の既定引数を `--name mdx_extra_q --jobs 1` に変更し、メモリ負荷を低減。
      - `UXMUSIC_LYRICS_SYNC_DEMUCS_MODEL` でモデル上書きを可能化。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7t` に更新。

### demucs diffq 依存エラー時の自動モデルフォールバック

- **課題**:
    - `demucs --name mdx_extra_q` 実行時に `diffq` 未導入エラーで ML 抽出が失敗するケースがあった。
- **対応**:
    - `internal/lyricssync/vocal_ml.go`:
      - 既定モデルを `mdx_extra` に変更し、追加依存なしで動作しやすい構成へ修正。
      - 指定モデル失敗時の再試行候補を生成し、`*_q` モデルで `diffq` エラー検出時は自動で非量子化モデルへフォールバック。
      - demucs 実行失敗ログを候補別に集約して返却するよう改善。
    - `internal/lyricssync/vocal_ml_test.go`:
      - `mdx_extra_q` 失敗（diffqエラー）から `mdx_extra` 成功へ自動切替するテストを追加。
      - モデル候補生成ロジックの単体テストを追加。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7u` に更新。

### 長尺曲での候補解析タイムアウト自動調整

- **課題**:
    - 長尺曲で `whisper` 候補解析が固定2分タイムアウトに達し、`context deadline exceeded` で失敗するケースがあった。
- **対応**:
    - `internal/lyricssync/syncer.go`:
      - `ffprobe` で音声長を取得し、`whisper` / `vocal-ml` タイムアウトを音声長ベースで動的算出するロジックを追加。
      - 段階別タイムアウト設定値をログ出力し、解析失敗時の原因切り分けを容易化。
      - `ffprobe` パス解決関数を追加（`config.FFprobePath` 優先 + `PATH` フォールバック）。
    - `internal/lyricssync/syncer_test.go`:
      - `computeWhisperTimeout` / `computeVocalMLTimeout` の単体テストを追加。
- **検証**:
    - `go test ./internal/lyricssync`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-7v` に更新。

---

## 2026年3月2日

### FLACインポート時のジャケット未取得修正（Wails）

- **課題**:
    - GUI起動時の限定 `PATH` 環境で `internal/scanner` が `ffmpeg/ffprobe` を解決できず、FLAC取り込み時にジャケット抽出とメタデータ補完が失敗するケースがあった。
- **対応**:
    - `internal/scanner/ffprobe.go`:
      - `resolveMediaCommandPath()` を強化し、以下の順で実行ファイルを探索するよう変更。
        - `config.FFmpegPath` / `config.FFprobePath`
        - `PATH`
        - `.app/Contents/Resources/bin` と `.app/Contents/Resources`
        - `/opt/homebrew/bin`, `/usr/local/bin`, `/opt/local/bin`, `/usr/bin`, `/bin`
      - 実行可能ファイル判定とキャッシュを追加し、無効パスの使い回しを防止。
    - `internal/scanner/ffprobe_test.go`:
      - 実行可能判定およびフォールバック候補生成の単体テストを追加。
- **検証**:
    - `go test ./internal/scanner`
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-8s` に更新。

### ラウドネス解析の復活（Wails）

- **課題**:
    - Wails 取り込み経路でラウドネス解析が実質的に走らず、`loudness` ストアが更新されにくい状態だった。
    - 並列解析時に `loudness` 保存が競合し、結果が取りこぼされる可能性があった。
- **対応**:
    - `app_normalize.go`:
      - 取り込み曲パスを受けてバックグラウンドでラウドネス解析する `queueLoudnessAnalysis()` を追加。
      - 既存 `loudness` 値がある曲はスキップするフィルタ処理を追加。
      - 解析結果を `loudness-analysis-result` イベントとしてフロントへ通知する処理を追加。
      - `saveLoudnessValue()` に排他制御（`loudnessMu`）を追加し、並列保存時の取りこぼしを防止。
    - `app_scanner.go`:
      - スキャン完了後に新規取り込み曲を対象としてラウドネス解析キューへ投入する処理を追加。
    - `app_youtube.go`:
      - YouTube 追加後の保存曲をラウドネス解析キューへ投入する処理を追加。
    - `app.go`:
      - `App` 構造体に `loudnessMu` を追加。
    - `app_normalize_test.go`:
      - 数値判定と解析対象フィルタの単体テストを追加。
- **検証**:
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-8t` に更新。

### 未解析曲の再生前ラウドネス解析を強化

- **課題**:
    - 未解析曲の再生時に同一曲への解析要求が重複送信される場合があり、再生待機フローが不安定になることがあった。
    - 解析結果イベントの値が欠落しているケースでログ整形が失敗する可能性があった。
- **対応**:
    - `src/renderer/js/features/playback-manager.js`:
      - ラウドネス値の判定を数値パース付きに統一し、未解析判定を厳密化。
      - 未解析時は再生前に必ず解析待ちへ遷移する処理を維持しつつ、同一パスの解析要求重複を抑止。
      - 解析完了時に保留中パスを解放するための関数を追加。
    - `src/renderer/js/core/ipc.js`:
      - `loudness-analysis-result` 受信時に解析保留状態を解除。
      - `filePath` / `loudness` の欠落時でも安全にログ出力できるようガードを追加。
- **検証**:
    - `node --check src/renderer/js/features/playback-manager.js`
    - `node --check src/renderer/js/core/ipc.js`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-8u` に更新。

### loudness.json 検索不一致対策（パス正規化対応）

- **課題**:
    - `loudness.json` には値が保存されているが、曲パスの Unicode 正規化差分（NFC/NFD）により検索や参照で一致しないケースがあった。
- **対応**:
    - `app_normalize.go`:
      - ラウドネス保存・参照のキー候補生成 `loudnessPathCandidates()` を追加（trim/clean/NFC/NFD）。
      - `GetLoudnessValue()` を候補キー順のフォールバック参照に変更。
      - `saveLoudnessValue()` を候補キーへ同時保存する実装に変更し、検索互換性を向上。
      - 未解析判定 `filterPendingLoudnessPaths()` を候補キー対応に変更し、正規化差分による二重解析を抑止。
    - `app_normalize_test.go`:
      - 正規化候補生成および正規化差分をまたぐ既存値判定の単体テストを追加。
- **検証**:
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-8v` に更新。

### インポート時の曲順崩れを修正（並列スキャン順の確定化）

- **課題**:
    - 取り込み時のメタデータ解析が並列実行されるため、インポート直後の曲順が実行ごとに不安定で、アルバム内トラック順が崩れることがあった。
- **対応**:
    - `app_scanner.go`:
      - `importSongsToLibrary()` の返却前に `sortSongsForLibrary()` を追加し、インポート配列を確定順へ整列。
      - ソート基準を追加（`albumartist/artist` → `album` → `discNumber` → `trackNumber` → `title` → `path`）。
      - `trackNumber` / `discNumber` が未設定（0以下）の場合は既知番号の後ろへ回すフォールバックを追加。
    - `app_scanner_test.go`:
      - ディスク番号・トラック番号の順序保証テストを追加。
      - トラック番号未設定時のタイトル・パスフォールバック順テストを追加。
- **検証**:
    - `go test ./...`
- **バージョン情報の更新**:
    - `src/renderer/js/core/bridge.js` と `requirement.md` のバージョンを `0.1.9-Beta-8w` に更新。

## 2026年5月26日

### モックUI (MusicCenterhommagesample.html) の手直し

- **要望対応**:
    - 「Music Center for PC」に近いUIモードを作成中だが、まだ相違があるため手直し。
    - 既存のアプリモードのコード（`src/` 配下）には触れずにモックHTMLのみ修正。
- **実装内容**:
    - トップヘッダー領域にあった再生コントロール（戻る、再生、進む など）を削除し、サイドバー（`aside`）の上部へ移動。
    - プレイリストおよびアルバムのグリッドビュー領域において、アイテムグリッドの上にソート用のテーブルヘッダ（「タイトル」「アーティスト」等）を追加。
    - 全体的な背景色を少し暗く（`#121212` 等）調整し、より実物のUIに近づけた。
    - **追加調整**: Pythonスクリプトによる画像色分析とPuppeteerによるレンダリング確認を行い、メイン背景色（`#1a1a1a`）とサイドバー背景色（`#343434`）のコントラストを忠実に再現。
    - タイトルの太字化、検索窓のアイコン左寄せ、ヘッダのレイアウト（件数表示の横並び化など）を本物の画面レイアウトに修正。
    - **構造的レイアウトの修正**: 「だいぶ違う」という印象の主な原因であった配置構造を見直し。メインタイトルと件数表示を「縦並び」にし、ソートヘッダ（テーブルの列名部分）が左右の余白を持たずにメイン領域の端から端まで広がるようにHTMLの階層構造とパディングを修正。
    - **再調整（ユーザー指摘）**: サイドバー上部に配置してしまった再生コントロール（戻る、再生、進むなど）を、本来のUI通り「トップヘッダー内の左側（アプリロゴの横）」へ配置し直しました。また、サイドバーとメイン領域（曲リスト等）の間の隙間が広すぎたため、パディングを `px-8` から `px-5` へ縮小し、よりタイトなレイアウトに改善しました。
- **テスト・品質担保**:
    - `mock_ui_test.mjs` を作成し、再生コントロールの位置やテーブルヘッダの存在を検証する簡易UI構造テストを実装し、Red -> Green を確認。
    - 修正にあわせてテスト仕様も更新（再生コントロールがヘッダー内に存在することを検証するように変更）。
- **バージョン情報の更新**:
    - モック修正のためバージョン更新は保留。
